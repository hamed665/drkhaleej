---
name: drmuscat-design
description: Use this skill to generate well-branded interfaces and assets for DrMuscat, the Oman-first bilingual (English + Arabic) healthcare discovery platform for Muscat — for production or for throwaway prototypes, mocks, and slides. Contains the brand's design guidelines, color and type tokens, fonts, logo assets, iconography, and a high-fidelity bilingual web UI kit.
user-invocable: true
---

Read the `README.md` file in this skill first — it carries the brand context, content/voice rules, visual
foundations, and iconography. Then explore the other files:

- `colors_and_type.css` — all design tokens (colors, type scale, spacing, radii, shadows). Import this in any
  artifact you build.
- `assets/` — logo marks (`logo-mark.svg`, `logo-mark-white.svg`, `logo-mark-tile.svg`). Copy these out; never
  redraw them.
- `preview/` — design-system specimen cards (colors, type, spacing, components, brand) you can reference for
  exact values and component looks.
- `ui_kits/web/` — a high-fidelity, interactive bilingual (EN/AR, LTR/RTL) web UI kit. Reuse its components and
  page structures (homepage, listing, provider detail, for-providers).

Core rules to honor every time:
- **Search-first.** On the homepage, the search/discovery panel must be visible above the fold.
- **Arabic is first-class.** Build real RTL with logical properties — never a mirrored afterthought. Keep Arabic
  headings smaller and line-height a touch larger; no English nav on Arabic screens except the language switch.
- **No fabricated data.** Never invent ratings, reviews, counts, "top doctor" labels, availability, awards, or
  sponsored blocks. Use only neutral, factual placeholder fields.
- **Calm & premium.** Deep teal-green identity, Omani gold as a sparing accent, soft elevation, generous space.
  Avoid SaaS/coupon/SEO-directory tropes, loud gradients, and emoji.
- **Canonical categories only:** Doctors · Centers · Pharmacies · Labs · Services · Search.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets out and produce static HTML files
for the user to view. If working on production code, copy assets and read the rules here to design as an expert in
this brand.

If the user invokes this skill without other guidance, ask what they want to build, ask a few focused questions
(surface, language(s), audience, fidelity, variations), then act as an expert designer who outputs HTML artifacts
or production-ready code as needed.
