# DrMuscat Design System — Export note / CHANGELOG

**Export date:** June 2026
**Status:** Design / prototype UI kit — **not production Next.js code.** No backend, database, Supabase,
real auth/OTP/OAuth, payments, WhatsApp API, geolocation, or AI chat. All such actions are UI placeholders.

## Latest change (QA refinement pass)
- **Added rating-distribution bars** to the reviews block on provider & doctor profiles. The block already
  showed an honest "No ratings yet" summary; it now also renders a 5★→1★ distribution chart.
  **Bars are zeroed/empty when there is no real review data — never fabricated.**

### Files changed
- `ui_kits/web/social.jsx` — `ReviewsBlock` now renders a `.rev-dist` (5→1 star) bar list beside the summary.
- `ui_kits/web/styles.css` — added `.rev-dist` / `.rev-dist-row` / `.rev-dist-bar` styles (+ mobile rule).
- `ui_kits/web/components.jsx`, `auth.jsx`, `dashboard.jsx` — logo `<img>` srcs now use `assetUrl(id, fallback)`
  so the standalone export can inline them via `window.__resources` (fallback paths keep the normal kit working).
- `ui_kits/web/_standalone.html` — bundler entry: `ext-resource-dependency` meta tags for the logo SVGs + a
  splash thumbnail. (Used only to produce the standalone file.)

## Verified after export (live-DOM checks)
- Homepage search card = **992px** wide, search-first, articles lower, featured below — overflow **0**.
- Country → City → Area hierarchy intact (City lists cities only; Area depends on city; Oman active + 6 "Coming soon").
- Doctor/provider reviews show the **honest "No ratings yet"** empty state.
- **Rating-distribution bars render** (5 rows, zeroed).
- Comments section present with **"Pending moderation"** state (سيظهر تعليقك بعد المراجعة).
- FAQ + nearby/sort sections present on listing & profiles.
- Arabic **RTL** intact (no English nav except the language switch); profile & homepage overflow **0**.

## Remaining limitations (honest)
- Screenshots were unavailable in the build environment, so QA used live-DOM measurements rather than pixel
  captures; responsive rules (320–1920) are those verified by the background verifier in prior rounds.
- Deep console sub-screens (media manager, offers manager, ads buying, analytics charts, team, support tickets,
  subdomain) are **representative placeholder panels + written specs**, not full bespoke UI — by design for a kit.
- The WhatsApp icon uses Lucide's `message-circle` (no brand glyph in Lucide); swap for the official mark in prod.
- Fonts (Readex Pro) load via Google Fonts; the standalone file inlines what the page references.

## How to run
- **Source kit:** open `ui_kits/web/index.html` (needs network for React/Babel/Lucide/Fonts CDNs).
- **Standalone:** `DrMuscat Web UI Kit.html` — single self-contained file, works fully offline.
- See `README.md` (root) and `ui_kits/web/README.md` for the full system, route map, and handoff notes.
