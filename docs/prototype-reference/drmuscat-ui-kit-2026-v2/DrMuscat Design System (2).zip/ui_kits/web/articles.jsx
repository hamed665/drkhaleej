/* DrMuscat kit — Articles / blog (public). No fake medical claims/reviews. */

function artCat(slug, locale) {
  const c = window.DM_DATA.articleCategories.find((x) => x.slug === slug);
  return c ? c[locale] : "";
}

function ArticleCard({ a, tr, locale, go, compact }) {
  return (
    <button className={"art-card" + (compact ? " compact" : "")} onClick={() => go({ name: "article", id: a.id })}>
      <span className="art-media">
        <Icon name={a.video ? "play-circle" : "image"} />
        {a.video ? <span className="art-vid"><Icon name="video" />{tr.articles.readMin === "min read" ? "Video" : "فيديو"}</span> : null}
      </span>
      <span className="art-body">
        <span className="art-cat">{artCat(a.cat, locale)}</span>
        <span className="art-title">{locale === "ar" ? a.ar : a.en}</span>
        <span className="art-ex">{locale === "ar" ? a.exAr : a.exEn}</span>
        <span className="art-meta">
          <span className="art-author"><Icon name="user" />{a.author}</span>
          <span className="art-read"><Icon name="clock" />{a.readMin} {tr.articles.readMin}</span>
        </span>
      </span>
    </button>
  );
}

function ArticlesIndex({ tr, locale, go }) {
  const D = window.DM_DATA, A = tr.articles;
  const [cat, setCat] = useState(null);
  const list = cat ? D.articles.filter((a) => a.cat === cat) : D.articles;
  const featured = D.articles[0];
  const byProviders = D.articles.filter((a) => a.author !== "DrMuscat").slice(0, 3);

  return (
    <main className="section">
      <div className="container">
        <div className="breadcrumb"><a onClick={() => go({ name: "home" })}>{tr.listing.breadcrumbHome}</a><Icon name="chevron-right" /><span>{A.title}</span></div>
        <div className="listing-head"><h1>{A.title}</h1><div className="loc">{A.sub}</div></div>

        <div className="sb-input art-search" style={{ marginTop: 18, maxWidth: 520 }}><Icon name="search" /><input placeholder={A.search} /></div>

        <div className="cat-switch chips" style={{ marginTop: 16 }}>
          <span className={"chip" + (!cat ? " on" : "")} onClick={() => setCat(null)}>{A.all}</span>
          {D.articleCategories.map((c) => (
            <span key={c.slug} className={"chip" + (cat === c.slug ? " on" : "")} onClick={() => setCat(c.slug)}>{c[locale]}</span>
          ))}
        </div>

        {!cat ? (
          <section style={{ marginTop: 28 }}>
            <button className="art-featured" onClick={() => go({ name: "article", id: featured.id })}>
              <span className="art-featured-media"><Icon name="image" /><span className="art-featured-tag">{A.featured}</span></span>
              <span className="art-featured-body">
                <span className="art-cat">{artCat(featured.cat, locale)}</span>
                <h2>{locale === "ar" ? featured.ar : featured.en}</h2>
                <p>{locale === "ar" ? featured.exAr : featured.exEn}</p>
                <span className="art-meta"><span className="art-author"><Icon name="user" />{featured.author}</span><span className="art-read"><Icon name="clock" />{featured.readMin} {A.readMin}</span></span>
              </span>
            </button>
          </section>
        ) : null}

        <section style={{ marginTop: 32 }}>
          <SectionHead title={A.latest} />
          <div className="art-grid">{list.map((a) => <ArticleCard key={a.id} a={a} tr={tr} locale={locale} go={go} />)}</div>
        </section>

        {!cat ? (
          <section className="section" style={{ paddingBottom: 0 }}>
            <SectionHead title={A.byProviders} />
            <div className="art-grid">{byProviders.map((a) => <ArticleCard key={a.id} a={a} tr={tr} locale={locale} go={go} />)}</div>
          </section>
        ) : null}
      </div>
    </main>
  );
}

function ArticleDetail({ tr, locale, go, page }) {
  const D = window.DM_DATA, A = tr.articles;
  const a = D.articles.find((x) => x.id === page.id) || D.articles[0];
  const related = D.articles.filter((x) => x.id !== a.id).slice(0, 3);
  const relProviders = D.providers.slice(0, 2);
  const paras = locale === "ar"
    ? ["هذا نص تجريبي لعرض تخطيط المقال. يقدّم درمسقط معلومات عامة وهادئة لمساعدتك على الاكتشاف، دون أي ادعاءات طبية.",
       "استخدم البحث حسب القسم والمنطقة للوصول إلى مزوّد مناسب، وأكّد التفاصيل دائمًا مباشرة مع المزود.",
       "للمحتوى الأطول، تظهر قائمة محتويات على اليمين لتسهيل التنقل بين الأقسام."]
    : ["This is placeholder body copy to show the article layout. DrMuscat shares calm, general information to help discovery — never medical claims.",
       "Use search by category and area to reach a suitable provider, and always confirm details directly with them.",
       "For longer pieces, a table of contents appears in the sidebar to help navigation between sections."];

  return (
    <main className="section">
      <div className="container article-wrap">
        <div className="breadcrumb">
          <a onClick={() => go({ name: "home" })}>{tr.listing.breadcrumbHome}</a><Icon name="chevron-right" />
          <a onClick={() => go({ name: "articles" })}>{A.title}</a><Icon name="chevron-right" /><span>{artCat(a.cat, locale)}</span>
        </div>

        <div className="article-head">
          <span className="art-cat">{artCat(a.cat, locale)}</span>
          <h1>{locale === "ar" ? a.ar : a.en}</h1>
          <p className="article-ex">{locale === "ar" ? a.exAr : a.exEn}</p>
          <div className="article-byline">
            <span className="art-author"><Icon name="user" />{A.by} {a.author}</span>
            <span className="art-read"><Icon name="calendar" />2026</span>
            <span className="art-read"><Icon name="clock" />{a.readMin} {A.readMin}</span>
            <button className="btn btn-ghost btn-sm"><Icon name="share-2" />{A.share}</button>
          </div>
        </div>

        <div className="article-hero">
          {a.video ? <span className="article-video"><Icon name="play-circle" /><span className="article-video-note">YouTube embed</span></span>
                   : <Icon name="image" />}
        </div>

        <div className="article-layout">
          <article className="article-body">
            {paras.map((p, i) => <p key={i}>{p}</p>)}
            <div className="article-figure"><Icon name="image" /><span>{locale === "ar" ? "صورة توضيحية — تعليق" : "Inline image — caption"}</span></div>
            {paras.slice(0, 2).map((p, i) => <p key={"b" + i}>{p}</p>)}
            <div className="notice warn" style={{ marginTop: 18 }}><Icon name="shield-check" /><p>{A.disclaimer}</p></div>
          </article>

          <aside className="article-aside">
            <div className="pd-block toc">
              <h2 style={{ fontSize: 15 }}>{A.toc}</h2>
              <a>1 · {locale === "ar" ? "نظرة عامة" : "Overview"}</a>
              <a>2 · {locale === "ar" ? "نصائح عملية" : "Practical tips"}</a>
              <a>3 · {locale === "ar" ? "الخطوات التالية" : "Next steps"}</a>
            </div>
            <div className="pd-block">
              <h2 style={{ fontSize: 15 }}>{A.relatedProviders}</h2>
              {relProviders.map((p) => (
                <button key={p.id} className="rel-prov" onClick={() => go({ name: "provider", id: p.id })}>
                  <span className="lead-ic"><Icon name="building-2" /></span>
                  <span className="lead-text"><span className="lead-name">{locale === "ar" ? p.ar : p.en}</span><span className="lead-meta">{provCat(p, locale)}</span></span>
                </button>
              ))}
            </div>
          </aside>
        </div>

        <div className="faq-narrow" style={{ marginTop: 8 }}><FAQ items={D.faqs.article[locale]} tr={tr} /></div>
        <div style={{ marginTop: 18 }} className="faq-narrow"><CommentsBlock tr={tr} locale={locale} /></div>

        <section style={{ marginTop: 24 }}>
          <SectionHead title={A.related} />
          <div className="art-grid">{related.map((r) => <ArticleCard key={r.id} a={r} tr={tr} locale={locale} go={go} />)}</div>
        </section>
      </div>
    </main>
  );
}

function HomeArticles({ tr, locale, go }) {
  const D = window.DM_DATA, A = tr.articles;
  const items = D.articles.slice(0, 3);
  return (
    <div className="container">
      <SectionHead eyebrow={A.title} title={A.homeTitle} sub={A.homeSub}
        action={<Btn variant="ghost" icon={locale === "ar" ? "chevron-left" : "chevron-right"} onClick={() => go({ name: "articles" })}>{A.exploreAll}</Btn>} />
      <div className="art-grid">{items.map((a) => <ArticleCard key={a.id} a={a} tr={tr} locale={locale} go={go} />)}</div>
    </div>
  );
}

Object.assign(window, { ArticlesIndex, ArticleDetail, HomeArticles, ArticleCard, artCat });
