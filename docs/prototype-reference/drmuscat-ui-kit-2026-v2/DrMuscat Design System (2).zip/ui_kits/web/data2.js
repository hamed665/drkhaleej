/* DrMuscat kit — data2: auth/onboarding, roles, dashboards, billing, locations.
   Design-only. No real auth, OTP, OAuth, payment, or backend. Extends window.DM_DATA. */
(function () {
  const D = window.DM_DATA;
  const T = D.t;

  /* ---------- Countries (Oman active; others future) ---------- */
  D.countries = [
    { code: "OM", en: "Oman", ar: "عُمان", active: true },
    { code: "AE", en: "United Arab Emirates", ar: "الإمارات العربية المتحدة", active: false },
    { code: "SA", en: "Saudi Arabia", ar: "السعودية", active: false },
    { code: "QA", en: "Qatar", ar: "قطر", active: false },
    { code: "BH", en: "Bahrain", ar: "البحرين", active: false },
    { code: "KW", en: "Kuwait", ar: "الكويت", active: false },
    { code: "IR", en: "Iran", ar: "إيران", active: false },
  ];

  /* Oman cities/governorates + Muscat areas (for the location picker) */
  D.omanCities = [
    { en: "Muscat", ar: "مسقط" }, { en: "Seeb", ar: "السيب" }, { en: "Bausher", ar: "بوشر" },
    { en: "Muttrah", ar: "مطرح" }, { en: "Amerat", ar: "العامرات" }, { en: "Quriyat", ar: "قريات" },
    { en: "Sohar", ar: "صحار" }, { en: "Salalah", ar: "صلالة" }, { en: "Nizwa", ar: "نزوى" },
    { en: "Sur", ar: "صور" }, { en: "Ibri", ar: "عبري" }, { en: "Buraimi", ar: "البريمي" },
    { en: "Rustaq", ar: "الرستاق" }, { en: "Ibra", ar: "إبراء" }, { en: "Khasab", ar: "خصب" },
    { en: "Duqm", ar: "الدقم" },
  ];

  /* ---------- Account types (onboarding) → dashboard role ---------- */
  D.accountTypes = [
    { id: "care",     role: "user",     icon: "heart-pulse",  en: "I am looking for care",                       ar: "أبحث عن رعاية" },
    { id: "doctor",   role: "doctor",   icon: "stethoscope",  en: "I am a doctor",                               ar: "أنا طبيب" },
    { id: "center",   role: "center",   icon: "building-2",   en: "I own or manage a clinic / center",           ar: "أملك أو أدير عيادة/مركزاً" },
    { id: "pharmacy", role: "pharmacy", icon: "pill",         en: "I own or manage a pharmacy",                  ar: "أملك أو أدير صيدلية" },
    { id: "lab",      role: "lab",      icon: "flask-conical",en: "I own or manage a laboratory",                ar: "أملك أو أدير مختبراً" },
    { id: "beauty",   role: "beauty",   icon: "sparkles",     en: "I provide beauty / wellness services",        ar: "أقدم خدمات تجميل أو عناية" },
    { id: "pet",      role: "pet",      icon: "paw-print",    en: "I own or manage a pet / veterinary clinic",   ar: "أملك أو أدير عيادة بيطرية" },
    { id: "marketer", role: "marketer", icon: "megaphone",    en: "I am a marketer / sales partner",             ar: "أنا مسوّق / شريك مبيعات" },
    { id: "other",    role: "provider", icon: "briefcase",    en: "Other service provider",                      ar: "مقدم خدمة آخر" },
  ];

  /* ---------- Role → dashboard config ---------- */
  // kind groups how the overview renders: user | provider | marketer
  D.roleConfig = {
    user:     { kind: "user",     menu: ["overview", "saved", "searches", "settings", "help"] },
    doctor:   { kind: "provider", menu: ["overview", "profile", "affiliations", "services", "schedule", "leads", "verification", "billing", "settings", "help"], plan: "free" },
    center:   { kind: "provider", menu: ["overview", "profile", "doctors", "services", "gallery", "offers", "leads", "verification", "billing", "settings", "help"], plan: "free" },
    pharmacy: { kind: "provider", menu: ["overview", "profile", "services", "schedule", "gallery", "leads", "verification", "billing", "settings", "help"], plan: "free" },
    lab:      { kind: "provider", menu: ["overview", "profile", "tests", "schedule", "leads", "verification", "billing", "settings", "help"], plan: "free" },
    beauty:   { kind: "provider", menu: ["overview", "profile", "services", "gallery", "leads", "verification", "billing", "settings", "help"], plan: "free" },
    pet:      { kind: "provider", menu: ["overview", "profile", "services", "schedule", "gallery", "leads", "verification", "billing", "settings", "help"], plan: "free" },
    provider: { kind: "provider", menu: ["overview", "profile", "services", "leads", "verification", "billing", "settings", "help"], plan: "free" },
    marketer: { kind: "marketer", menu: ["overview", "leads", "providers", "followups", "territory", "commission", "payouts", "settings", "help"] },
  };

  /* ---------- Subscription plans (future placeholders; pricing NOT final) ---------- */
  D.plans = [
    { id: "free",    en: "Free listing",      ar: "إدراج مجاني",  featsEn: ["Basic profile", "Appear in search", "Contact buttons"], featsAr: ["ملف أساسي", "الظهور في البحث", "أزرار التواصل"] },
    { id: "starter", en: "Verified starter",  ar: "بداية موثقة",  featsEn: ["Everything in Free", "Verification review", "More photos"], featsAr: ["كل ما في المجاني", "مراجعة التوثيق", "صور أكثر"] },
    { id: "growth",  en: "Growth partner",    ar: "شريك نمو",     featsEn: ["Priority in results", "Offers & packages", "Lead inbox"], featsAr: ["أولوية في النتائج", "عروض وباقات", "صندوق طلبات"] },
    { id: "premium", en: "Premium visibility",ar: "ظهور مميز",    featsEn: ["Featured placement", "Top of category", "Insights"], featsAr: ["ظهور بارز", "أعلى القسم", "إحصاءات"] },
    { id: "ads",     en: "Ads / featured",    ar: "إعلانات / مميز", future: true, featsEn: ["Sponsored slots", "Ad credits / wallet", "Campaigns"], featsAr: ["مساحات مموّلة", "رصيد إعلاني", "حملات"] },
  ];

  /* ============================ i18n ============================ */
  T.en.authNav = { signin: "Sign in", register: "Register", dashboard: "Dashboard", signout: "Sign out" };
  T.ar.authNav = { signin: "تسجيل الدخول", register: "إنشاء حساب", dashboard: "لوحة التحكم", signout: "تسجيل الخروج" };

  T.en.auth = {
    signinTitle: "Welcome back", signinSub: "Sign in to manage your profile and discovery.",
    registerTitle: "Create your account", registerSub: "No email needed — Google or your phone is enough.",
    google: "Continue with Google", phone: "Continue with phone number", guest: "Continue as guest",
    terms: "By continuing you agree to our Terms and Privacy notice. Design placeholder — nothing is submitted.",
    otpTitle: "Verify your number", otpSub: "We sent a 6-digit code to",
    phoneLabel: "Phone number", phonePlaceholder: "+968 ____ ____",
    sendOtp: "Send code", codeLabel: "Verification code", verify: "Verify & continue",
    resend: "Resend code", changeNumber: "Change number", resendIn: "Resend in",
    googleDoneTitle: "Google account connected", googleDoneSub: "Complete a few basics to continue.",
    typeTitle: "What are you joining as?", typeSub: "We'll tailor your experience and dashboard.",
    setupTitle: "Set up your profile", setupSub: "Just the basics — you can complete the rest later.",
    finish: "Finish & go to dashboard", back: "Back", next: "Continue", skip: "Skip for now",
    f: { name: "Name", nameOpt: "Name (optional)", specialty: "Specialty", clinic: "Current clinic / center (optional)",
         center: "Center name", business: "Business / provider name", providerType: "Provider type", category: "Category",
         country: "Country", city: "City", area: "Area", contact: "Contact person", phone: "Phone", whatsapp: "WhatsApp",
         email: "Email (optional)", lang: "Preferred language", own: "I own or manage this", note: "Short note",
         territory: "Expected area / territory", langEn: "English", langAr: "العربية" },
  };
  T.ar.auth = {
    signinTitle: "مرحبًا بعودتك", signinSub: "سجّل الدخول لإدارة ملفك واكتشافك.",
    registerTitle: "أنشئ حسابك", registerSub: "بلا بريد إلكتروني — جوجل أو هاتفك يكفي.",
    google: "المتابعة عبر جوجل", phone: "المتابعة برقم الهاتف", guest: "المتابعة كزائر",
    terms: "بالمتابعة فإنك توافق على الشروط وإشعار الخصوصية. نموذج تصميمي — لا يُرسل شيء.",
    otpTitle: "تأكيد رقمك", otpSub: "أرسلنا رمزًا من ٦ أرقام إلى",
    phoneLabel: "رقم الهاتف", phonePlaceholder: "+968 ____ ____",
    sendOtp: "إرسال الرمز", codeLabel: "رمز التحقق", verify: "تحقّق وتابع",
    resend: "إعادة إرسال الرمز", changeNumber: "تغيير الرقم", resendIn: "إعادة الإرسال بعد",
    googleDoneTitle: "تم ربط حساب جوجل", googleDoneSub: "أكمل بعض الأساسيات للمتابعة.",
    typeTitle: "بأي صفة تنضم؟", typeSub: "سنخصّص تجربتك ولوحة التحكم.",
    setupTitle: "إعداد ملفك", setupSub: "الأساسيات فقط — يمكنك إكمال الباقي لاحقًا.",
    finish: "إنهاء والانتقال للوحة", back: "رجوع", next: "متابعة", skip: "تخطٍّ الآن",
    f: { name: "الاسم", nameOpt: "الاسم (اختياري)", specialty: "التخصص", clinic: "العيادة/المركز الحالي (اختياري)",
         center: "اسم المركز", business: "اسم النشاط / المزود", providerType: "نوع المزود", category: "القسم",
         country: "الدولة", city: "المدينة", area: "المنطقة", contact: "الشخص المسؤول", phone: "الهاتف", whatsapp: "واتساب",
         email: "البريد (اختياري)", lang: "اللغة المفضلة", own: "أملك أو أدير هذا", note: "ملاحظة قصيرة",
         territory: "المنطقة / النطاق المتوقع", langEn: "English", langAr: "العربية" },
  };

  // dashboard menu labels + panels
  T.en.dash = {
    title: "Dashboard", roleSwitch: "Preview role", previewNote: "Design preview — sample data, no real account.",
    completion: "Profile completion", viewPublic: "View public profile", continue: "Continue setup",
    status: { draft: "Draft", pending: "Pending review", live: "Live", rejected: "Needs changes" },
    menu: { overview: "Overview", profile: "Profile", listings: "Listings", doctors: "Doctors / team", affiliations: "Clinics & affiliations",
            services: "Services", tests: "Test categories", schedule: "Schedule & hours", gallery: "Gallery", offers: "Offers & packages",
            leads: "Leads / inquiries", verification: "Verification", billing: "Subscription & billing", settings: "Settings", help: "Help",
            saved: "Saved providers", searches: "Recent searches", providers: "Providers", followups: "Follow-ups",
            territory: "Territory", commission: "Commission", payouts: "Payouts" },
    cards: { leads: "New inquiries", views: "Profile views", saved: "Saved by users", completion: "Completion",
             assigned: "Assigned providers", onboarding: "Onboarding", followups: "Follow-ups due", commission: "Commission (est.)" },
    sampleData: "Sample data", emptyLeads: "No inquiries yet. They'll appear here.",
    savedEmpty: "Providers you save will appear here.", searchEmpty: "Your recent searches will appear here.",
    claimCta: "Claim an existing profile", requestCta: "Request a listing",
    verifyTitle: "Verification status", verifyBody: "Submit basic details and an optional license to request a verified badge. Review is manual.",
    verifyCta: "Request verification", settingsLang: "Preferred language", settingsArea: "Preferred areas", settingsNotif: "Notifications",
  };
  T.ar.dash = {
    title: "لوحة التحكم", roleSwitch: "معاينة الدور", previewNote: "معاينة تصميم — بيانات تجريبية، بلا حساب حقيقي.",
    completion: "اكتمال الملف", viewPublic: "عرض الملف العام", continue: "متابعة الإعداد",
    status: { draft: "مسودة", pending: "قيد المراجعة", live: "منشور", rejected: "يحتاج تعديلًا" },
    menu: { overview: "نظرة عامة", profile: "الملف", listings: "القوائم", doctors: "الأطباء / الفريق", affiliations: "العيادات والانتماءات",
            services: "الخدمات", tests: "فئات الفحوصات", schedule: "الجدول والساعات", gallery: "المعرض", offers: "العروض والباقات",
            leads: "الطلبات", verification: "التوثيق", billing: "الاشتراك والفوترة", settings: "الإعدادات", help: "المساعدة",
            saved: "المحفوظون", searches: "عمليات البحث الأخيرة", providers: "المزودون", followups: "المتابعات",
            territory: "النطاق", commission: "العمولة", payouts: "المدفوعات" },
    cards: { leads: "طلبات جديدة", views: "مشاهدات الملف", saved: "حُفظ من المستخدمين", completion: "الاكتمال",
             assigned: "مزودون معيّنون", onboarding: "قيد الإعداد", followups: "متابعات مستحقة", commission: "العمولة (تقديري)" },
    sampleData: "بيانات تجريبية", emptyLeads: "لا توجد طلبات بعد. ستظهر هنا.",
    savedEmpty: "سيظهر هنا المزودون الذين تحفظهم.", searchEmpty: "ستظهر هنا عمليات بحثك الأخيرة.",
    claimCta: "طالب بملف موجود", requestCta: "اطلب إدراجًا",
    verifyTitle: "حالة التوثيق", verifyBody: "أرسل بيانات أساسية ورخصة اختيارية لطلب شارة التوثيق. المراجعة يدوية.",
    verifyCta: "طلب التوثيق", settingsLang: "اللغة المفضلة", settingsArea: "المناطق المفضلة", settingsNotif: "التنبيهات",
  };

  // billing
  T.en.billing = {
    title: "Subscription & billing", disclaimer: "Plans and payments are not finalised yet. This is a future billing placeholder for design only.",
    current: "Current plan", currentVal: "Free listing", upgrade: "Upgrade plan", choose: "Choose plan", currentTag: "Current",
    history: "Billing history", historyEmpty: "No billing history — payments are not active yet.",
    method: "Payment method", methodNote: "Bank transfer & online payment will be added later.",
    states: "Payment states (concept)", pending: "Pending", paid: "Paid", failed: "Failed", soon: "Future", wallet: "Ad credits / wallet",
  };
  T.ar.billing = {
    title: "الاشتراك والفوترة", disclaimer: "الخطط والمدفوعات غير نهائية حاليًا. هذا نموذج تصميم فقط للفوترة المستقبلية.",
    current: "الخطة الحالية", currentVal: "إدراج مجاني", upgrade: "ترقية الخطة", choose: "اختر الخطة", currentTag: "الحالية",
    history: "سجل الفوترة", historyEmpty: "لا يوجد سجل فوترة — المدفوعات غير مفعّلة بعد.",
    method: "طريقة الدفع", methodNote: "سيُضاف التحويل البنكي والدفع الإلكتروني لاحقًا.",
    states: "حالات الدفع (مفهوم)", pending: "معلّق", paid: "مدفوع", failed: "فشل", soon: "لاحقًا", wallet: "رصيد إعلاني",
  };

  // claim flow
  T.en.claim = {
    title: "Claim your profile",
    steps: ["Find your profile", "Confirm ownership", "Verify by phone", "Documents (optional)", "Submitted"],
    searchPlaceholder: "Search your center, clinic or pharmacy name",
    select: "Select", selected: "Selected", own: "I confirm I own or manage this profile",
    phone: "Phone / WhatsApp for verification", sendOtp: "Send code", code: "Verification code",
    docTitle: "License / document (optional)", docNote: "Upload a trade license or medical permit. Design placeholder — no file is uploaded.",
    docCta: "Choose file", submit: "Submit claim", doneTitle: "Claim submitted", doneBody: "Your claim is pending review. We'll contact you on the number provided.",
    pending: "Pending review", back: "Back", next: "Continue",
  };
  T.ar.claim = {
    title: "طالب بملفك",
    steps: ["ابحث عن ملفك", "تأكيد الملكية", "التحقق بالهاتف", "المستندات (اختياري)", "تم الإرسال"],
    searchPlaceholder: "ابحث باسم مركزك أو عيادتك أو صيدليتك",
    select: "اختيار", selected: "محدد", own: "أؤكد أنني أملك أو أدير هذا الملف",
    phone: "الهاتف / واتساب للتحقق", sendOtp: "إرسال الرمز", code: "رمز التحقق",
    docTitle: "رخصة / مستند (اختياري)", docNote: "ارفع السجل التجاري أو التصريح الطبي. نموذج تصميمي — لا يُرفع ملف.",
    docCta: "اختر ملفًا", submit: "إرسال الطلب", doneTitle: "تم إرسال الطلب", doneBody: "طلبك قيد المراجعة. سنتواصل معك على الرقم المُدخل.",
    pending: "قيد المراجعة", back: "رجوع", next: "متابعة",
  };

  // request listing extra fields + states
  T.en.reqx = {
    providerType: "Provider type", country: "Country", city: "City", contactPerson: "Contact person name",
    phone: "Contact phone number", whatsapp: "WhatsApp number", email: "Email address (optional)",
    own: "Do you own or manage this center?", lang: "Preferred language", yes: "Yes", no: "No, I'm referring it",
    submitted: "Request received", submittedBody: "Thanks — your listing request is pending review. We'll reach out on the phone number you gave us.",
    pending: "Pending review", another: "Submit another", required: "Phone number is required.",
  };
  T.ar.reqx = {
    providerType: "نوع المزود", country: "الدولة", city: "المدينة", contactPerson: "اسم الشخص المسؤول",
    phone: "رقم الهاتف", whatsapp: "رقم واتساب", email: "البريد الإلكتروني (اختياري)",
    own: "هل تملك أو تدير هذا المركز؟", lang: "اللغة المفضلة", yes: "نعم", no: "لا، أُحيله فقط",
    submitted: "تم استلام الطلب", submittedBody: "شكرًا — طلب الإدراج قيد المراجعة. سنتواصل معك على الرقم الذي أدخلته.",
    pending: "قيد المراجعة", another: "إرسال طلب آخر", required: "رقم الهاتف مطلوب.",
  };

  // location picker
  T.en.locp = { country: "Country", cityArea: "City or area", soon: "Soon", pick: "Choose location", popularCities: "Cities", areas: "Muscat areas", use: "Use" };
  T.ar.locp = { country: "الدولة", cityArea: "المدينة أو المنطقة", soon: "قريبًا", pick: "اختر الموقع", popularCities: "المدن", areas: "مناطق مسقط", use: "استخدام" };

  // doctor-profile extra
  T.en.doc = { specialty: "Specialty", subspecialty: "Sub-specialty", experience: "Years of experience", education: "Education",
    certs: "Certifications", conditions: "Conditions treated", affiliation: "Current clinic / center", requestAppt: "Request appointment",
    share: "Share profile", relatedDoctors: "Related doctors", apptNote: "Appointment requests are a design placeholder — confirm directly with the clinic." };
  T.ar.doc = { specialty: "التخصص", subspecialty: "التخصص الدقيق", experience: "سنوات الخبرة", education: "التعليم",
    certs: "الشهادات", conditions: "الحالات المُعالَجة", affiliation: "العيادة / المركز الحالي", requestAppt: "طلب موعد",
    share: "مشاركة الملف", relatedDoctors: "أطباء مشابهون", apptNote: "طلب الموعد عنصر تصميمي — يُرجى التأكيد مباشرة مع العيادة." };

  /* ===== Country → City → Area (dependent) ===== */
  D.cityAreas = {
    "Muscat": [
      { en: "Al Khuwair", ar: "الخوير" }, { en: "Azaiba", ar: "العذيبة" }, { en: "Qurum", ar: "القرم" },
      { en: "Ruwi", ar: "روي" }, { en: "Al Ghubrah", ar: "الغبرة" }, { en: "Madinat Qaboos", ar: "مدينة قابوس" },
      { en: "Muscat Hills", ar: "مسقط هيلز" }, { en: "Al Hail", ar: "الحيل" }, { en: "Mawaleh", ar: "الموالح" },
      { en: "Muttrah", ar: "مطرح" }, { en: "Bausher", ar: "بوشر" },
    ],
    "Seeb": [
      { en: "Al Hail", ar: "الحيل" }, { en: "Mawaleh", ar: "الموالح" }, { en: "Seeb Souq", ar: "سوق السيب" },
      { en: "Al Khoud", ar: "الخوض" }, { en: "Al Mouj", ar: "الموج" }, { en: "Mabela", ar: "المعبيلة" },
    ],
    "Salalah": [
      { en: "Salalah Central", ar: "صلالة المركز" }, { en: "Al Saada", ar: "السعادة" },
      { en: "Awqad", ar: "عوقد" }, { en: "Dahariz", ar: "الدهاريز" },
    ],
    "Bausher": [
      { en: "Bausher", ar: "بوشر" }, { en: "Al Ansab", ar: "الأنصب" }, { en: "Ghala", ar: "غلا" },
      { en: "Al Khuwair", ar: "الخوير" }, { en: "Al Ghubrah", ar: "الغبرة" },
    ],
    "Muttrah": [
      { en: "Muttrah", ar: "مطرح" }, { en: "Ruwi", ar: "روي" }, { en: "Wadi Kabir", ar: "الوادي الكبير" },
      { en: "Darsait", ar: "دارسيت" },
    ],
    "Sohar": [
      { en: "Sohar Central", ar: "صحار المركز" }, { en: "Al Hambar", ar: "الهمبار" },
      { en: "Falaj Al Qabail", ar: "فلج القبائل" }, { en: "Majan", ar: "مجان" },
    ],
  };

  /* ===== Simplified registration: 3 main types → provider sub-types ===== */
  D.mainTypes = [
    { id: "care", role: "user", icon: "heart-pulse", en: "I am looking for care", ar: "أبحث عن رعاية" },
    { id: "provider", icon: "building-2", en: "I am a healthcare / provider business", ar: "أنا مقدم رعاية أو نشاط صحي" },
    { id: "marketer", role: "marketer", icon: "megaphone", en: "I am a marketer / sales partner", ar: "أنا مسوّق / شريك مبيعات" },
  ];
  D.providerTypes = [
    { id: "doctor", role: "doctor", icon: "stethoscope", en: "Doctor", ar: "طبيب" },
    { id: "center", role: "center", icon: "building-2", en: "Clinic / medical center", ar: "عيادة / مركز طبي" },
    { id: "pharmacy", role: "pharmacy", icon: "pill", en: "Pharmacy", ar: "صيدلية" },
    { id: "lab", role: "lab", icon: "flask-conical", en: "Laboratory", ar: "مختبر" },
    { id: "beauty", role: "beauty", icon: "sparkles", en: "Beauty / wellness provider", ar: "مقدم تجميل أو عناية" },
    { id: "pet", role: "pet", icon: "paw-print", en: "Pet clinic / veterinary", ar: "عيادة بيطرية" },
    { id: "hospital", role: "center", icon: "cross", en: "Hospital", ar: "مستشفى" },
    { id: "other", role: "provider", icon: "briefcase", en: "Other provider", ar: "مقدم خدمة آخر" },
  ];

  /* ===== Articles ===== */
  D.articleCategories = [
    { slug: "health-guide", en: "Health guide", ar: "دليل الصحة" },
    { slug: "dental-care", en: "Dental care", ar: "العناية بالأسنان" },
    { slug: "pharmacy-guide", en: "Pharmacy guide", ar: "دليل الصيدليات" },
    { slug: "lab-tests", en: "Lab tests", ar: "الفحوصات المخبرية" },
    { slug: "beauty-wellness", en: "Beauty & wellness", ar: "التجميل والعناية" },
    { slug: "pet-care", en: "Pet care", ar: "رعاية الحيوانات" },
    { slug: "clinic-updates", en: "Clinic updates", ar: "أخبار المراكز" },
    { slug: "doctor-advice", en: "Doctor advice", ar: "نصائح الأطباء" },
    { slug: "oman-healthcare", en: "Oman healthcare guide", ar: "دليل الرعاية في عُمان" },
    { slug: "provider-education", en: "Provider education", ar: "توعية مقدمي الرعاية" },
  ];
  D.articles = [
    { id: "a1", cat: "health-guide", video: false, readMin: 5, author: "DrMuscat",
      en: "A calm guide to finding the right clinic in Muscat", ar: "دليل هادئ للعثور على العيادة المناسبة في مسقط",
      exEn: "How to search by area, category and service to reach trusted care faster.",
      exAr: "كيف تبحث حسب المنطقة والقسم والخدمة للوصول إلى رعاية موثوقة بسرعة." },
    { id: "a2", cat: "dental-care", video: true, readMin: 4, author: "Madinat Qaboos Dental Clinic",
      en: "Caring for your teeth between dental visits", ar: "العناية بأسنانك بين زيارات الطبيب",
      exEn: "Simple daily habits that keep your smile healthy, explained clearly.",
      exAr: "عادات يومية بسيطة تحافظ على صحة ابتسامتك، بشرح واضح." },
    { id: "a3", cat: "lab-tests", video: false, readMin: 6, author: "Ruwi Diagnostic Laboratory",
      en: "Understanding common blood tests", ar: "فهم فحوصات الدم الشائعة",
      exEn: "What routine panels measure and how to prepare for sample collection.",
      exAr: "ما الذي تقيسه الفحوصات الروتينية وكيف تستعد لسحب العينة." },
    { id: "a4", cat: "pet-care", video: false, readMin: 3, author: "Azaiba Pet Clinic",
      en: "Keeping your pet's vaccinations on schedule", ar: "الحفاظ على مواعيد تطعيم حيوانك الأليف",
      exEn: "A gentle overview of routine vaccination timing for cats and dogs.",
      exAr: "نظرة لطيفة على توقيت التطعيمات الروتينية للقطط والكلاب." },
    { id: "a5", cat: "beauty-wellness", video: true, readMin: 5, author: "Qurum Wellness & Beauty Clinic",
      en: "Building a calm, sustainable wellness routine", ar: "بناء روتين عافية هادئ ومستدام",
      exEn: "Balanced movement, recovery and skin care without the noise.",
      exAr: "حركة متوازنة وتعافٍ وعناية بالبشرة بعيدًا عن الضجيج." },
    { id: "a6", cat: "oman-healthcare", video: false, readMin: 7, author: "DrMuscat",
      en: "Navigating healthcare across Oman's governorates", ar: "التنقل في الرعاية الصحية عبر محافظات عُمان",
      exEn: "From Muscat to Salalah — how discovery works across regions.",
      exAr: "من مسقط إلى صلالة — كيف يعمل الاكتشاف عبر المناطق." },
  ];

  /* ===== Admin & Super Admin roles (internal/invited — not public selectable) ===== */
  D.roleConfig.admin = { kind: "admin", menu: ["overview", "providersMgmt", "claims", "listingRequests", "verificationQueue", "contentReview", "mediaReview", "offersReview", "adsReview", "leads", "messages", "payments", "reports", "users", "settings"] };
  D.roleConfig.superAdmin = { kind: "superadmin", menu: ["overview", "roles", "admins", "plans", "locations", "categories", "ads", "seo", "translations", "auditLog", "systemHealth", "platformSettings"] };
  // enrich provider menus with media/offers/articles/analytics/ads/messages
  D.roleConfig.center.menu = ["overview", "profile", "doctors", "services", "media", "offers", "articles", "leads", "analytics", "ads", "verification", "billing", "messages", "settings", "help"];
  D.roleConfig.doctor.menu = ["overview", "profile", "affiliations", "services", "media", "articles", "schedule", "leads", "analytics", "verification", "billing", "messages", "settings", "help"];
  ["pharmacy", "lab", "beauty", "pet", "provider"].forEach((r) => {
    D.roleConfig[r].menu = ["overview", "profile", "services", "media", "offers", "leads", "analytics", "ads", "verification", "billing", "messages", "settings", "help"];
  });

  /* ===== Plan feature matrix ===== */
  D.planCols = ["free", "starter", "growth", "premium"];
  D.planMatrix = [
    { en: "Public profile", ar: "ملف عام", v: [1, 1, 1, 1] },
    { en: "Category & area listing", ar: "إدراج بالقسم والمنطقة", v: [1, 1, 1, 1] },
    { en: "Verified status (after review)", ar: "حالة موثّقة (بعد المراجعة)", v: [0, 1, 1, 1] },
    { en: "Gallery & photos", ar: "معرض وصور", v: [0, 1, 1, 1] },
    { en: "WhatsApp / Call / Directions", ar: "واتساب / اتصال / اتجاهات", v: [0, 1, 1, 1] },
    { en: "Offers & packages", ar: "عروض وباقات", v: [0, 0, 1, 1] },
    { en: "Leads & analytics", ar: "طلبات وتحليلات", v: [0, 0, 1, 1] },
    { en: "Article submission", ar: "نشر المقالات", v: [0, 0, 1, 1] },
    { en: "Featured placement eligibility", ar: "أهلية الظهور المميز", v: [0, 0, 0, 1] },
    { en: "Subdomain / microsite", ar: "نطاق فرعي / موقع مصغّر", v: [0, 0, 0, 1] },
  ];

  /* ===== i18n: auth password/forgot ===== */
  Object.assign(T.en.auth, {
    password: "Continue with email or phone and password", emailPhone: "Email or phone", pwd: "Password",
    createPwd: "Create a password (optional)", forgot: "Forgot password?", reset: "Reset password",
    resetSub: "Enter your email or phone and we'll send reset instructions.", sendReset: "Send reset link",
    signinPwd: "Sign in", pwdCreatedTitle: "You're all set", pwdCreatedSub: "Your password is saved. (Design placeholder.)",
    newPwd: "New password", confirmPwd: "Confirm password", or: "or",
  });
  Object.assign(T.ar.auth, {
    password: "المتابعة بالبريد أو الهاتف وكلمة المرور", emailPhone: "البريد أو الهاتف", pwd: "كلمة المرور",
    createPwd: "إنشاء كلمة مرور (اختياري)", forgot: "هل نسيت كلمة المرور؟", reset: "إعادة تعيين كلمة المرور",
    resetSub: "أدخل بريدك أو هاتفك وسنرسل تعليمات إعادة التعيين.", sendReset: "إرسال رابط إعادة التعيين",
    signinPwd: "تسجيل الدخول", pwdCreatedTitle: "كل شيء جاهز", pwdCreatedSub: "تم حفظ كلمة المرور. (نموذج تصميمي.)",
    newPwd: "كلمة مرور جديدة", confirmPwd: "تأكيد كلمة المرور", or: "أو",
  });

  /* extra dashboard menu labels (provider + admin + super admin) */
  Object.assign(T.en.dash.menu, { media: "Media", analytics: "Analytics", ads: "Ads / featured", messages: "Messages", team: "Team",
    providersMgmt: "Providers", claims: "Claim requests", listingRequests: "Listing requests", verificationQueue: "Verification queue",
    contentReview: "Articles review", mediaReview: "Media review", offersReview: "Offers review", adsReview: "Ads review",
    payments: "Payments", reports: "Reports", users: "Users", roles: "Roles & permissions", admins: "Admins",
    plans: "Plans", locations: "Locations", categories: "Categories", seo: "SEO controls", translations: "Translations",
    auditLog: "Audit log", systemHealth: "System health", platformSettings: "Platform settings" });
  Object.assign(T.ar.dash.menu, { media: "الوسائط", analytics: "التحليلات", ads: "إعلانات / مميز", messages: "الرسائل", team: "الفريق",
    providersMgmt: "المزودون", claims: "طلبات المطالبة", listingRequests: "طلبات الإدراج", verificationQueue: "قائمة التوثيق",
    contentReview: "مراجعة المقالات", mediaReview: "مراجعة الوسائط", offersReview: "مراجعة العروض", adsReview: "مراجعة الإعلانات",
    payments: "المدفوعات", reports: "التقارير", users: "المستخدمون", roles: "الأدوار والصلاحيات", admins: "المسؤولون",
    plans: "الخطط", locations: "المواقع", categories: "الأقسام", seo: "ضبط SEO", translations: "الترجمات",
    auditLog: "سجل التدقيق", systemHealth: "صحة النظام", platformSettings: "إعدادات المنصة" });
  Object.assign(T.en.dash, { locked: "Locked", upgrade: "Upgrade", upgradeReq: "Upgrade required", planMatrix: "Compare plans", feature: "Feature" });
  Object.assign(T.ar.dash, { locked: "مقفل", upgrade: "ترقية", upgradeReq: "تحتاج ترقية", planMatrix: "قارن الخطط", feature: "الميزة" });

  /* ===== i18n: articles ===== */
  T.en.articles = { title: "Articles & health guides", sub: "Calm, practical guides and updates for Oman.",
    featured: "Featured", latest: "Latest articles", popular: "Popular health guides", byProviders: "From providers & doctors",
    search: "Search articles", readMin: "min read", read: "Read article", related: "Related articles",
    relatedProviders: "Related providers", categoriesLabel: "Categories", all: "All",
    disclaimer: "General information only — not medical advice or diagnosis. Always consult a qualified professional.",
    toc: "On this page", share: "Share", homeTitle: "Health guides and updates", homeSub: "Calm, practical reading from DrMuscat.",
    homePopular: "Popular health guides in Oman", exploreAll: "Explore all articles", back: "Back to articles", by: "By" };
  T.ar.articles = { title: "المقالات والأدلة الصحية", sub: "أدلة وتحديثات هادئة وعملية لعُمان.",
    featured: "مميّز", latest: "أحدث المقالات", popular: "أدلة صحية شائعة", byProviders: "من المزودين والأطباء",
    search: "ابحث في المقالات", readMin: "دقيقة قراءة", read: "اقرأ المقال", related: "مقالات ذات صلة",
    relatedProviders: "مزودون ذوو صلة", categoriesLabel: "الأقسام", all: "الكل",
    disclaimer: "معلومات عامة فقط — ليست نصيحة طبية أو تشخيصًا. استشر مختصًا مؤهلًا دائمًا.",
    toc: "في هذه الصفحة", share: "مشاركة", homeTitle: "أدلة صحية وتحديثات", homeSub: "قراءة هادئة وعملية من درمسقط.",
    homePopular: "أدلة صحية شائعة في عُمان", exploreAll: "تصفح كل المقالات", back: "العودة للمقالات", by: "بقلم" };

  /* ===== i18n: floating support (WhatsApp + AI) ===== */
  T.en.fab = { whatsapp: "WhatsApp us", ai: "Ask AI", help: "Need help?", aiTitle: "Chat with DrMuscat AI",
    welcome: "Hi, I can help you search DrMuscat, find categories, or guide you to list your center. I cannot provide medical diagnosis.",
    placeholder: "Ask about search, categories or listing…", send: "Send",
    quick: ["Find a clinic near me", "Browse categories", "List my center"], close: "Close",
    note: "AI assistant — design placeholder. No medical diagnosis." };
  T.ar.fab = { whatsapp: "تواصل عبر واتساب", ai: "اسأل الذكاء الاصطناعي", help: "تحتاج مساعدة؟", aiTitle: "تحدث مع مساعد دكتور مسقط",
    welcome: "مرحبًا، يمكنني مساعدتك في البحث داخل دكتور مسقط أو إرشادك لإدراج مركزك. لا أقدم تشخيصًا طبيًا.",
    placeholder: "اسأل عن البحث أو الأقسام أو الإدراج…", send: "إرسال",
    quick: ["ابحث عن عيادة قريبة", "تصفح الأقسام", "أدرج مركزي"], close: "إغلاق",
    note: "مساعد ذكي — نموذج تصميمي. لا يقدم تشخيصًا طبيًا." };

  // nav: articles
  T.en.nav.articles = "Articles";
  T.ar.nav.articles = "المقالات";

  /* ===== FAQs (SEO/GEO-ready accordion content) ===== */
  D.faqs = {
    home: { en: [
        { q: "How does DrMuscat help me find care?", a: "Search by service, category and area to discover clinics, doctors, pharmacies, labs and wellness providers across Oman, then contact them directly." },
        { q: "Can I contact providers through WhatsApp?", a: "Yes — listings show WhatsApp, call and directions actions so you can reach a provider directly. DrMuscat does not handle the conversation." },
        { q: "Are listings verified?", a: "Some providers complete a verification review. Verification status is shown only after a manual check — never fabricated." },
        { q: "Can I search by area in Oman?", a: "Yes. Choose a country, then a city/governorate, then a neighbourhood/area to narrow results." },
        { q: "Is DrMuscat a medical advice service?", a: "No. DrMuscat is a discovery directory and shares general information only — not medical advice or diagnosis." },
      ], ar: [
        { q: "كيف يساعدني دكتور مسقط في العثور على الرعاية؟", a: "ابحث حسب الخدمة والقسم والمنطقة لاكتشاف العيادات والأطباء والصيدليات والمختبرات ومقدمي العافية في عُمان، ثم تواصل معهم مباشرة." },
        { q: "هل يمكنني التواصل مع مقدمي الرعاية عبر واتساب؟", a: "نعم — تعرض القوائم أزرار واتساب والاتصال والاتجاهات للتواصل المباشر مع المزود. لا يتدخل دكتور مسقط في المحادثة." },
        { q: "هل الملفات موثقة؟", a: "بعض المزودين يكملون مراجعة التوثيق. تظهر حالة التوثيق بعد فحص يدوي فقط — ولا تُختلق أبدًا." },
        { q: "هل يمكنني البحث حسب المنطقة في عُمان؟", a: "نعم. اختر الدولة ثم المدينة/المحافظة ثم الحي/المنطقة لتضييق النتائج." },
        { q: "هل دكتور مسقط يقدم نصيحة طبية؟", a: "لا. دكتور مسقط دليل اكتشاف يقدم معلومات عامة فقط — وليست نصيحة أو تشخيصًا طبيًا." },
      ] },
    provider: { en: [
        { q: "How do I contact this provider?", a: "Use the WhatsApp, call or directions buttons on the profile. Always confirm details directly before visiting." },
        { q: "Are the listed hours guaranteed?", a: "Hours are provided by the listing and may change. Please confirm with the provider." },
        { q: "Is this provider verified?", a: "Verification is shown only when completed through a manual review — otherwise no badge is displayed." },
        { q: "Can I leave a review?", a: "Yes. Reviews are moderated before publishing and must follow our trust & safety rules." },
      ], ar: [
        { q: "كيف أتواصل مع هذا المزود؟", a: "استخدم أزرار واتساب أو الاتصال أو الاتجاهات في الملف. أكّد التفاصيل مباشرة قبل الزيارة دائمًا." },
        { q: "هل ساعات العمل المعروضة مضمونة؟", a: "الساعات مقدّمة من القائمة وقد تتغير. يُرجى التأكيد مع المزود." },
        { q: "هل هذا المزود موثّق؟", a: "تظهر حالة التوثيق فقط بعد مراجعة يدوية — وإلا لا تُعرض أي شارة." },
        { q: "هل يمكنني كتابة تقييم؟", a: "نعم. تُراجَع التقييمات قبل النشر ويجب أن تتبع قواعد الثقة والسلامة." },
      ] },
    article: { en: [
        { q: "Is this article medical advice?", a: "No. Articles share general, calm information for discovery and education — not diagnosis or treatment advice." },
        { q: "Who writes DrMuscat articles?", a: "Articles may be written by DrMuscat or by listed providers and doctors; provider content is reviewed before publishing." },
        { q: "How do I find a provider for this topic?", a: "Use the related providers and categories on this page, or search by area from the homepage." },
      ], ar: [
        { q: "هل هذا المقال نصيحة طبية؟", a: "لا. تقدم المقالات معلومات عامة وهادئة للاكتشاف والتوعية — وليست تشخيصًا أو نصيحة علاجية." },
        { q: "من يكتب مقالات دكتور مسقط؟", a: "قد تُكتب المقالات من دكتور مسقط أو من مزودين وأطباء مدرجين؛ ويُراجَع محتوى المزودين قبل النشر." },
        { q: "كيف أجد مزودًا لهذا الموضوع؟", a: "استخدم المزودين والأقسام ذات الصلة في هذه الصفحة، أو ابحث حسب المنطقة من الصفحة الرئيسية." },
      ] },
    category: { en: [
        { q: "How are providers listed in this category?", a: "Listings are organised by category and area. Some are verified after a manual review; none are ranked by paid placement unless clearly marked." },
        { q: "Can I filter by area?", a: "Yes — use the area filter to find providers in a specific Muscat neighbourhood or Oman city." },
        { q: "How do I list my business here?", a: "Use \u201cList your center\u201d to request a listing or claim an existing profile." },
      ], ar: [
        { q: "كيف يُدرج المزودون في هذا القسم؟", a: "تُنظَّم القوائم حسب القسم والمنطقة. بعضها موثّق بعد مراجعة يدوية؛ ولا تُرتَّب بالدفع إلا بوضوح." },
        { q: "هل يمكنني التصفية حسب المنطقة؟", a: "نعم — استخدم تصفية المنطقة للعثور على مزودين في حي بمسقط أو مدينة عُمانية." },
        { q: "كيف أُدرج نشاطي هنا؟", a: "استخدم «أدرج مركزك» لطلب إدراج أو المطالبة بملف موجود." },
      ] },
  };

  /* ===== i18n: FAQ + reviews + comments ===== */
  T.en.faq = { title: "Frequently asked questions", sub: "Calm, factual answers — not medical advice." };
  T.ar.faq = { title: "الأسئلة الشائعة", sub: "إجابات هادئة وواقعية — وليست نصيحة طبية." };
  T.en.reviews = { title: "Reviews", write: "Write a review", summaryEmpty: "No ratings yet", empty: "No reviews yet. Be the first to share a verified experience.",
    sort: "Sort", filter: "Filter", yourRating: "Your rating", yourReview: "Your review", placeholder: "Share a factual, respectful experience…",
    submit: "Submit for review", pending: "Pending moderation", note: "Reviews are moderated before publishing. No fake ratings, no medical claims — misinformation can be reported and removed.",
    response: "Response from provider", report: "Report", cancel: "Cancel" };
  T.ar.reviews = { title: "التقييمات", write: "اكتب تقييماً", summaryEmpty: "لا توجد تقييمات بعد", empty: "لا توجد تقييمات بعد. كن أول من يشارك تجربة موثوقة.",
    sort: "ترتيب", filter: "تصفية", yourRating: "تقييمك", yourReview: "تقييمك المكتوب", placeholder: "شارك تجربة واقعية ومحترمة…",
    submit: "إرسال للمراجعة", pending: "قيد المراجعة", note: "تُراجَع التقييمات قبل النشر. لا تقييمات زائفة ولا ادعاءات طبية — ويمكن الإبلاغ عن المعلومات المضللة وإزالتها.",
    response: "رد من مقدم الخدمة", report: "إبلاغ", cancel: "إلغاء" };
  T.en.comments = { title: "Comments", empty: "No comments yet.", add: "Add a comment", placeholder: "Share a respectful comment…", submit: "Post comment",
    pending: "Pending moderation", note: "Comments are moderated. Please keep it respectful and free of medical misinformation." };
  T.ar.comments = { title: "التعليقات", empty: "لا توجد تعليقات بعد.", add: "أضف تعليقًا", placeholder: "شارك تعليقًا محترمًا…", submit: "نشر التعليق",
    pending: "قيد المراجعة", note: "تُراجَع التعليقات. يُرجى الالتزام بالاحترام وتجنّب المعلومات الطبية المضللة." };

  /* ===== nearby / sort / ratings labels + save/share ===== */
  Object.assign(T.en.cta, { save: "Save", share: "Share", saved: "Saved", claim2: "Claim this profile", report: "Report incorrect info", suggest: "Suggest an edit", openMap2: "Open map", viewOffers: "View offers" });
  Object.assign(T.ar.cta, { save: "حفظ", share: "مشاركة", saved: "محفوظ", claim2: "المطالبة بهذا الملف", report: "الإبلاغ عن معلومات خاطئة", suggest: "اقتراح تعديل", openMap2: "افتح الخريطة", viewOffers: "عرض العروض" });
  T.en.near = { me: "Near me", closest: "Closest first", openNow: "Open now", rating: "Top rated", relevance: "Relevance",
    useLoc: "Use my location", chooseArea: "Choose area manually", nearby: "Nearby", near: "Near", away: "km away",
    verifiedOnly: "Verified only", offers: "Offers", insurance: "Insurance accepted", sortBy: "Sort by", map: "Map", list: "List",
    noReviews: "No reviews yet", locNote: "Location is a design placeholder — choose an area manually.", lastUpdated: "Last updated", updatedVal: "Apr 2026" };
  T.ar.near = { me: "بالقرب مني", closest: "الأقرب أولاً", openNow: "مفتوح الآن", rating: "الأعلى تقييماً", relevance: "الأكثر صلة",
    useLoc: "استخدم موقعي", chooseArea: "اختر المنطقة يدوياً", nearby: "بالقرب", near: "بالقرب من", away: "كم",
    verifiedOnly: "موثّق فقط", offers: "عروض", insurance: "يقبل التأمين", sortBy: "ترتيب حسب", map: "خريطة", list: "قائمة",
    noReviews: "لا توجد تقييمات بعد", locNote: "الموقع عنصر تصميمي — اختر المنطقة يدوياً.", lastUpdated: "آخر تحديث", updatedVal: "أبريل ٢٠٢٦" };
})();
