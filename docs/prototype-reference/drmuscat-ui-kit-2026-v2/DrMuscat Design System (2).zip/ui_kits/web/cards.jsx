/* DrMuscat kit — search, cards, sections, states */

function SearchPanel({ tr, locale, go, compact }) {
  const cats = window.DM_DATA.categories;
  return (
    <div className="searchpanel">
      <div className="sp-label">{tr.search.label}</div>
      <div className="sp-row">
        <div className="sp-field sp-q">
          <Icon name="search" />
          <input placeholder={tr.search.placeholder} aria-label={tr.search.label} />
        </div>
        <div className="sp-field sp-loc">
          <Icon name="map-pin" />
          <input defaultValue={tr.search.location} aria-label={tr.search.locationLabel} />
        </div>
        <button className="btn btn-primary sp-cta" onClick={() => go({ name: "listing", category: null })}>
          <Icon name="search" />{tr.search.cta}
        </button>
      </div>
      <div className="sp-browse">
        <span className="lbl">{tr.search.browse}</span>
        <div className="chips">
          {cats.map((c) => (
            <span key={c.key} className="chip" onClick={() => go({ name: "listing", category: c.key })}>
              <Icon name={c.icon} />{c[locale]}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function CategoryCard({ cat, locale, go }) {
  return (
    <div className="cat-card" onClick={() => go({ name: "listing", category: cat.key })}>
      <div className="cat-ic"><Icon name={cat.icon} /></div>
      <h3>{cat[locale]}</h3>
      <p>{locale === "ar" ? cat.blurbAr : cat.blurbEn}</p>
    </div>
  );
}

function SectionHead({ eyebrow, title, sub, action }) {
  return (
    <div className="sec-head">
      <div>
        {eyebrow ? <div className="eyebrow">{eyebrow}</div> : null}
        <h2>{title}</h2>
        {sub ? <p>{sub}</p> : null}
      </div>
      {action || null}
    </div>
  );
}

function categoryLabel(key, locale) {
  const c = window.DM_DATA.categories.find((x) => x.key === key);
  return c ? c[locale] : "";
}
function provCat(p, locale) {
  if (locale === "ar" && p.dispAr) return p.dispAr;
  if (locale === "en" && p.dispEn) return p.dispEn;
  return categoryLabel(p.category, locale);
}

function ProviderCard({ p, tr, locale, go }) {
  const name = locale === "ar" ? p.ar : p.en;
  const area = locale === "ar" ? p.area.ar : p.area.en;
  const hours = locale === "ar" ? p.hoursAr : p.hoursEn;
  const desc = locale === "ar" ? p.descAr : p.descEn;
  const tags = locale === "ar" ? p.tags.ar : p.tags.en;
  return (
    <div className="pcard" onClick={() => go({ name: "provider", id: p.id })}>
      <div className="pcard-media">
        <Icon name="image" />
        {p.verified ? <span className="pcard-verified"><Icon name="badge-check" />{locale === "ar" ? "موثّق" : "Verified"}</span> : null}
      </div>
      <div className="pcard-body">
        <div className="cat">{provCat(p, locale)}</div>
        <h3>{name}</h3>
        <div className="pcard-rating">
          <Stars value={0} /><span className="pcard-rating-lbl">{tr.near.noReviews}</span>
        </div>
        <div className="meta"><Icon name="map-pin" />{tr.near.near} {area}</div>
        <div className="meta"><Icon name="clock" />{hours}</div>
        <div className="desc">{desc}</div>
        <div className="tagrow">{tags.map((t, i) => <span key={i} className="tag">{t}</span>)}</div>
        <div className="pcard-contact" onClick={(e) => e.stopPropagation()}>
          <Btn variant="whatsapp" size="sm" icon="message-circle">{tr.cta.whatsapp}</Btn>
          <IconBtn variant="secondary" size="sm" icon="phone" title={tr.cta.call} />
          <IconBtn variant="secondary" size="sm" icon="navigation" title={tr.cta.directions} />
        </div>
        <button className="btn btn-primary btn-block btn-sm pcard-view" onClick={() => go({ name: "provider", id: p.id })}>
          {tr.cta.viewProfile}
        </button>
      </div>
    </div>
  );
}

function EmptyState({ tr, onReset }) {
  return (
    <div className="empty">
      <div className="ic"><Icon name="search-x" /></div>
      <h3>{tr.empty.title}</h3>
      <p>{tr.empty.body}</p>
      <Btn variant="secondary" onClick={onReset}>{tr.empty.reset}</Btn>
    </div>
  );
}

Object.assign(window, { SearchPanel, CategoryCard, SectionHead, ProviderCard, EmptyState, categoryLabel, provCat });
