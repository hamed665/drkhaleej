/* DrMuscat kit — global floating support: WhatsApp + AI chat (design only, no real chat) */

function FloatingSupport({ tr, locale, go, raised }) {
  const F = tr.fab;
  const [open, setOpen] = useState(false);
  return (
    <div className={"fab-wrap" + (raised ? " raised" : "")}>
      {open ? (
        <div className="ai-panel" role="dialog" aria-label={F.aiTitle}>
          <div className="ai-head">
            <span className="ai-head-l"><span className="ai-avatar"><Icon name="sparkles" /></span>{F.aiTitle}</span>
            <button className="ai-x" onClick={() => setOpen(false)} aria-label={F.close}><Icon name="x" /></button>
          </div>
          <div className="ai-body">
            <div className="ai-msg"><span className="ai-avatar sm"><Icon name="sparkles" /></span><p>{F.welcome}</p></div>
            <div className="ai-quick">
              {F.quick.map((q, i) => (
                <button key={i} className="ai-chip" onClick={() => { setOpen(false); go(i === 2 ? { name: "forProviders" } : { name: "listing", category: null }); }}>{q}</button>
              ))}
            </div>
          </div>
          <div className="ai-input">
            <input placeholder={F.placeholder} aria-label={F.aiTitle} />
            <button className="btn btn-primary btn-icon btn-sm" aria-label={F.send}><Icon name="arrow-up" /></button>
          </div>
          <div className="ai-note"><Icon name="info" />{F.note}</div>
        </div>
      ) : null}
      <div className="fab-stack">
        <button className="fab fab-ai" onClick={() => setOpen((o) => !o)} title={F.ai}>
          <Icon name="sparkles" /><span className="fab-lbl">{F.ai}</span>
        </button>
        <button className="fab fab-wa" title={F.whatsapp}>
          <Icon name="message-circle" /><span className="fab-lbl">{F.whatsapp}</span>
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { FloatingSupport });
