/* DrMuscat kit — pages: Provider detail + For providers */

const SERVICES = {
  doctors:    { en: ["Consultation", "Follow-up visit", "Teleconsultation"], ar: ["استشارة", "زيارة متابعة", "استشارة عن بُعد"] },
  centers:    { en: ["Family medicine", "Diagnostics", "Specialist referral"], ar: ["طب الأسرة", "التشخيص", "إحالة لأخصائي"] },
  pharmacies: { en: ["Prescription dispensing", "Home delivery", "Wellness products"], ar: ["صرف الوصفات", "توصيل للمنزل", "منتجات العافية"] },
  labs:       { en: ["Blood tests", "Sample collection", "Reports & results"], ar: ["فحوصات الدم", "سحب العينات", "التقارير والنتائج"] },
  services:   { en: ["Physiotherapy", "Wellness sessions", "Guided recovery"], ar: ["علاج طبيعي", "جلسات عافية", "تعافٍ موجّه"] },
};

function ProviderPage({ tr, locale, go, page }) {
  const D = window.DM_DATA;
  const p = D.providers.find((x) => x.id === page.id) || D.providers[0];
  const name = locale === "ar" ? p.ar : p.en;
  const area = locale === "ar" ? p.area.ar : p.area.en;
  const hours = locale === "ar" ? p.hoursAr : p.hoursEn;
  const desc = locale === "ar" ? p.descAr : p.descEn;
  const tags = locale === "ar" ? p.tags.ar : p.tags.en;
  const svc = (SERVICES[p.category] || SERVICES.centers)[locale];
  const related = D.providers.filter((x) => x.category === p.category && x.id !== p.id).slice(0, 3);
  const catName = categoryLabel(p.category, locale);
  const dispName = provCat(p, locale);
  const langs = locale === "ar" ? "العربية · English" : "Arabic · English";
  const isDoctor = p.category === "doctors";
  const DOC = tr.doc;
  const specialty = locale === "ar" ? (p.specialtyAr || dispName) : (p.specialtyEn || dispName);

  return (
    <main className="section">
      <div className="container">
        <div className="breadcrumb">
          <a onClick={() => go({ name: "home" })}>{tr.listing.breadcrumbHome}</a>
          <Icon name="chevron-right" />
          <a onClick={() => go({ name: "listing", category: p.category })}>{catName}</a>
          <Icon name="chevron-right" />
          <span>{name}</span>
        </div>

        <div className="pd-hero">
          <div className="pd-cover"><Icon name="image" /></div>
          <div className="pd-head">
            <div className="grow">
              <div className="cat">{dispName}</div>
              <h1>{name}</h1>
              <div className="pd-rating-row">
                {p.verified ? <span className="pd-verified"><Icon name="badge-check" />{locale === "ar" ? "موثّق" : "Verified"}</span> : null}
                <span className="pd-rating"><Stars value={0} /><span className="muted">{tr.near.noReviews}</span></span>
              </div>
              <div className="pd-head-metas" style={{ display: "flex", gap: 18, flexWrap: "wrap" }}>
                <div className="meta"><Icon name="map-pin" />{area} · {tr.search.location.split(",")[0]}</div>
                <div className="meta"><Icon name="clock" />{hours}</div>
                <div className="meta"><Icon name="globe" />{langs}</div>
              </div>
              <div className="tagrow" style={{ marginTop: 12 }}>
                {tags.map((t, i) => <span key={i} className="tag">{t}</span>)}
              </div>
            </div>
            <div className="pd-actions">
              {isDoctor ? <Btn variant="primary" icon="calendar-check">{DOC.requestAppt}</Btn> : null}
              <Btn variant="whatsapp" icon="message-circle">{tr.cta.whatsapp}</Btn>
              <Btn variant="secondary" icon="phone">{tr.cta.call}</Btn>
              <Btn variant="secondary" icon="navigation">{tr.cta.directions}</Btn>
              <IconBtn variant="secondary" icon="bookmark" title={tr.cta.save} />
              <IconBtn variant="secondary" icon="share-2" title={tr.cta.share} />
            </div>
          </div>
        </div>

        <div className="pd-layout">
          <div>
            <div className="pd-block">
              <h2>{tr.provider.about}</h2>
              <p>{desc}</p>
            </div>

            {isDoctor ? (
              <div className="pd-block">
                <h2>{DOC.specialty}</h2>
                <div className="info-grid">
                  <div className="info-row"><Icon name="stethoscope" /><div><div className="k">{DOC.specialty}</div><div className="v">{specialty}</div></div></div>
                  <div className="info-row"><Icon name="layers" /><div><div className="k">{DOC.subspecialty}</div><div className="v">— <span className="sample-pill">{tr.provider.sampleTag}</span></div></div></div>
                  <div className="info-row"><Icon name="award" /><div><div className="k">{DOC.experience}</div><div className="v">10+ <span className="sample-pill">{tr.provider.sampleTag}</span></div></div></div>
                  <div className="info-row"><Icon name="graduation-cap" /><div><div className="k">{DOC.education}</div><div className="v">— <span className="sample-pill">{tr.provider.sampleTag}</span></div></div></div>
                  <div className="info-row"><Icon name="badge-check" /><div><div className="k">{DOC.certs}</div><div className="v">— <span className="sample-pill">{tr.provider.sampleTag}</span></div></div></div>
                  <div className="info-row"><Icon name="building-2" /><div><div className="k">{DOC.affiliation}</div><div className="v">{area} · {tr.search.location.split(",")[0]}</div></div></div>
                </div>
              </div>
            ) : null}

            <div className="pd-block">
              <h2>{tr.provider.services}</h2>
              <div className="svc-list">
                {svc.map((s, i) => (
                  <div key={i} className="svc-item"><Icon name="check" />{s}</div>
                ))}
              </div>
            </div>

            <div className="pd-block">
              <h2>{tr.provider.practical}</h2>
              <div className="info-grid">
                <div className="info-row"><Icon name="building-2" /><div><div className="k">{tr.provider.category}</div><div className="v">{catName}</div></div></div>
                <div className="info-row"><Icon name="map-pin" /><div><div className="k">{tr.provider.area}</div><div className="v">{area}</div></div></div>
                <div className="info-row"><Icon name="clock" /><div><div className="k">{tr.provider.hours}</div><div className="v">{hours}</div></div></div>
                <div className="info-row"><Icon name="globe" /><div><div className="k">{tr.provider.languages}</div><div className="v">{langs}</div></div></div>
                <div className="info-row"><Icon name="shield-check" /><div><div className="k">{tr.provider.payment}</div><div className="v">{tr.provider.paymentVal} <span className="sample-pill">{tr.provider.sampleTag}</span></div></div></div>
                <div className="info-row"><Icon name="car" /><div><div className="k">{tr.provider.access}</div><div className="v">{tr.provider.accessVal} <span className="sample-pill">{tr.provider.sampleTag}</span></div></div></div>
              </div>
            </div>

            <div className="pd-block">
              <h2>{tr.provider.location}</h2>
              <div className="map-placeholder lg"><Icon name="map" />{tr.provider.mapPlaceholder}</div>
              <div className="loc-row">
                <Icon name="map-pin" />
                <div><div className="k">{tr.provider.address}</div><div className="v">{area} · {tr.search.location}</div></div>
                <Btn variant="secondary" size="sm" icon="navigation" onClick={() => {}}>{tr.cta.getDirections}</Btn>
              </div>
              <div className="nearby">
                <span className="nearby-lbl">{tr.provider.nearby}</span>
                <div className="chips">
                  {D.areas.slice(0, 4).map((a, i) => (
                    <span key={i} className="chip" onClick={() => go({ name: "listing", category: null })}>{a[locale]}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pd-block">
              <h2>{tr.provider.gallery}</h2>
              <div className="gallery">
                <div className="g"><Icon name="image" /></div>
                <div className="g"><Icon name="image" /></div>
                <div className="g"><Icon name="image" /></div>
              </div>
            </div>
          </div>

          <aside className="pd-aside">
            <div className="pd-block" style={{ marginBottom: 14 }}>
              <h2 style={{ fontSize: 17 }}>{tr.provider.contact}</h2>
              <div style={{ display: "flex", flexDirection: "column", gap: 9, marginTop: 4 }}>
                <Btn variant="whatsapp" block icon="message-circle">{tr.cta.whatsapp}</Btn>
                <Btn variant="primary" block icon="phone">{tr.cta.call}</Btn>
                <Btn variant="secondary" block icon="navigation">{tr.cta.getDirections}</Btn>
              </div>
              <div className="map-placeholder" style={{ marginTop: 14 }}>
                <Icon name="map" />{tr.provider.mapPlaceholder}
              </div>
              <button className="btn btn-ghost btn-block btn-sm" style={{ marginTop: 8 }}><Icon name="external-link" />{tr.cta.openMap}</button>
              {isDoctor ? <div className="appt-note"><Icon name="info" />{DOC.apptNote}</div> : null}
            </div>
            <div className="notice">
              <Icon name="shield-check" />
              <p>{tr.provider.notice}</p>
            </div>
            <div className="pd-meta-links">
              <button onClick={() => go({ name: "claim" })}><Icon name="shield-check" />{tr.cta.claim2}</button>
              <button><Icon name="flag" />{tr.cta.report}</button>
              <button><Icon name="pencil" />{tr.cta.suggest}</button>
              <span className="pd-updated">{tr.near.lastUpdated}: {tr.near.updatedVal}</span>
            </div>
          </aside>
        </div>

        {related.length ? (
          <section style={{ marginTop: 40 }}>
            <SectionHead title={isDoctor ? DOC.relatedDoctors : tr.provider.related} />
            <div className="pgrid">
              {related.map((rp) => <ProviderCard key={rp.id} p={rp} tr={tr} locale={locale} go={go} />)}
            </div>
          </section>
        ) : null}

        <div style={{ marginTop: 24 }}><ReviewsBlock tr={tr} locale={locale} /></div>
        <div style={{ marginTop: 18 }}><CommentsBlock tr={tr} locale={locale} /></div>
        <div style={{ marginTop: 18 }} className="faq-narrow"><FAQ items={D.faqs.provider[locale]} tr={tr} /></div>
      </div>

      {/* mobile sticky contact */}
      <div className="pd-mobilebar">
        <Btn variant="whatsapp" block icon="message-circle">{tr.cta.whatsapp}</Btn>
        <Btn variant="primary" block icon="phone">{tr.cta.call}</Btn>
        <IconBtn variant="secondary" icon="navigation" title={tr.cta.directions} />
        <IconBtn variant="secondary" icon="bookmark" title={tr.cta.save} />
      </div>
    </main>
  );
}

function ForProvidersPage({ tr, locale, go }) {
  const F = tr.forProviders;
  const R = tr.reqx;
  const D = window.DM_DATA;
  const [submitted, setSubmitted] = useState(false);
  return (
    <main className="section">
      <div className="container">
        <div className="breadcrumb">
          <a onClick={() => go({ name: "home" })}>{tr.listing.breadcrumbHome}</a>
          <Icon name="chevron-right" />
          <span>{tr.nav.providers}</span>
        </div>

        <div className="fp-hero">
          <div className="eyebrow">{F.eyebrow}</div>
          <h1>{F.title}</h1>
          <p>{F.sub}</p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <Btn variant="gold" icon="arrow-right" onClick={() => { const el = document.getElementById("fp-form"); if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 80, behavior: "smooth" }); }}>{F.formCta}</Btn>
            <button className="btn btn-secondary fp-outline" onClick={() => { const el = document.getElementById("fp-form"); if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 80, behavior: "smooth" }); }}>{tr.cta.claim}</button>
            <button className="btn btn-ghost fp-ghost" onClick={() => { const el = document.getElementById("fp-form"); if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 80, behavior: "smooth" }); }}>{tr.cta.talk}</button>
          </div>
        </div>

        <section className="section" style={{ paddingBottom: 24 }}>
          <SectionHead title={F.benefitsTitle} />
          <div className="fp-grid">
            {F.benefits.map((b, i) => (
              <div key={i} className="fp-benefit">
                <div className="ic"><Icon name={b.icon} /></div>
                <h3>{b.t}</h3>
                <p>{b.b}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="section" style={{ paddingTop: 0, paddingBottom: 24 }}>
          <SectionHead title={F.howTitle} />
          <div className="fp-steps">
            {F.steps.map((s, i) => (
              <div key={i} className="fp-step">
                <div className="n">{s.n}</div>
                <div><h3>{s.t}</h3><p>{s.b}</p></div>
              </div>
            ))}
          </div>
        </section>

        {/* Profile preview */}
        <section className="section" style={{ paddingTop: 0, paddingBottom: 24 }}>
          <SectionHead title={F.previewTitle} sub={F.previewNote} />
          <div className="fp-preview">
            <ProviderCard p={window.DM_DATA.providers[0]} tr={tr} locale={locale} go={go} />
          </div>
        </section>

        {/* Plans placeholder — clearly future */}
        <section className="section" style={{ paddingTop: 0, paddingBottom: 24 }}>
          <div className="fp-plans">
            <div className="fp-plans-ic"><Icon name="layers" /></div>
            <div className="fp-plans-text">
              <div className="fp-plans-head"><h3>{F.plansTitle}</h3><span className="soon-pill">{F.plansSoon}</span></div>
              <p>{F.plansNote}</p>
            </div>
          </div>
        </section>

        <section className="section" style={{ paddingTop: 0 }} id="fp-form">
          <SectionHead title={F.formTitle} />
          {submitted ? (
            <div className="fp-form">
              <div className="claim-done">
                <div className="done-ic"><Icon name="check" /></div>
                <h2>{R.submitted}</h2>
                <p>{R.submittedBody}</p>
                <span className="status-pill pending"><span className="dot"></span>{R.pending}</span>
                <div style={{ marginTop: 18 }}>
                  <Btn variant="secondary" size="sm" icon="plus" onClick={() => setSubmitted(false)}>{R.another}</Btn>
                </div>
              </div>
            </div>
          ) : (
            <div className="fp-form">
              <div className="field"><label>{F.formName}</label><input placeholder={F.formName} /></div>
              <div className="form-row">
                <div className="field"><label>{R.providerType}</label>
                  <select>{D.accountTypes.slice(1).map((a) => <option key={a.id}>{a[locale]}</option>)}</select></div>
                <div className="field"><label>{F.formCat}</label>
                  <select>{D.categories.map((c) => <option key={c.key}>{c[locale]}</option>)}</select></div>
              </div>
              <LocationSelect tr={tr} locale={locale} span />
              <div className="form-row">
                <div className="field"><label>{R.contactPerson}</label><input placeholder={R.contactPerson} /></div>
                <div className="field"><label>{R.phone} <span className="req">*</span></label><input defaultValue="+968 " /></div>
              </div>
              <div className="form-row">
                <div className="field"><label>{R.whatsapp}</label><input defaultValue="+968 " /></div>
                <div className="field"><label>{R.email}</label><input placeholder={R.email} /></div>
              </div>
              <div className="form-row">
                <div className="field"><label>{R.own}</label>
                  <select><option>{R.yes}</option><option>{R.no}</option></select></div>
                <div className="field"><label>{R.lang}</label>
                  <select><option>{tr.auth.f.langEn}</option><option>{tr.auth.f.langAr}</option></select></div>
              </div>
              <div className="field"><label>{F.formMsg}</label><textarea placeholder={F.formMsg}></textarea></div>
              <div className="form-note">{R.required}</div>
              <Btn variant="primary" icon="send" onClick={() => setSubmitted(true)}>{F.formCta}</Btn>
              <div className="form-note">{F.formNote}</div>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

Object.assign(window, { ProviderPage, ForProvidersPage });
