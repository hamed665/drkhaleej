/* DrMuscat kit — discovery components: SearchBox (autocomplete), FeaturedCarousel,
   RichCategoryGrid, AreaSection, TrustSection */

/* ---------------- Powerful search with grouped autocomplete ---------------- */
function SearchBox({ tr, locale, go, variant }) {
  const D = window.DM_DATA;
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(-1);
  const [locOpen, setLocOpen] = useState(false);
  const [locVal, setLocVal] = useState(null);
  const [selCity, setSelCity] = useState(null);
  const wrapRef = useRef(null);

  useEffect(() => {
    const onDoc = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) { setOpen(false); setLocOpen(false); } };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const query = q.trim();
  const ql = query.toLowerCase();
  const matches = query
    ? D.suggestIndex.filter((s) => s.en.toLowerCase().includes(ql) || s.ar.includes(query))
    : [];
  const order = ["category", "provider", "service", "area"];
  const grouped = order.map((tp) => ({ tp, items: matches.filter((m) => m.type === tp) })).filter((g) => g.items.length);
  const flat = grouped.reduce((a, g) => a.concat(g.items), []);
  const typeIcon = { category: "layout-grid", provider: "building-2", service: "search", area: "map-pin" };
  const groupLabel = { category: tr.search.suggCat, provider: tr.search.suggProv, service: tr.search.suggSvc, area: tr.search.suggArea };

  const choose = (route) => { setOpen(false); setQ(""); go(route); };
  const onKey = (e) => {
    if (!open) return;
    if (e.key === "ArrowDown") { e.preventDefault(); setHi((h) => Math.min(h + 1, flat.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
    else if (e.key === "Enter") { if (flat[hi]) choose(flat[hi].route); else go({ name: "listing", category: null }); }
    else if (e.key === "Escape") setOpen(false);
  };

  let flatIdx = -1;
  return (
    <div className={"searchbox" + (variant === "compact" ? " compact" : "")} ref={wrapRef}>
      <div className="sb-panel">
        {variant !== "compact" ? <div className="sb-label">{tr.search.label}</div> : null}
        <div className="sb-fieldwrap">
          <div className="sb-row">
            <div className="sb-input">
              <Icon name="search" />
              <input
                value={q}
                onChange={(e) => { setQ(e.target.value); setOpen(true); setHi(-1); }}
                onFocus={() => setOpen(true)}
                onKeyDown={onKey}
                placeholder={tr.search.placeholder}
                aria-label={tr.search.label}
              />
              {q ? <button className="sb-clear" onClick={() => { setQ(""); setHi(-1); }} aria-label={tr.search.clear}><Icon name="x" /></button> : null}
            </div>
            <div className="sb-loc">
              <Icon name="map-pin" />
              <button type="button" className="sb-loc-btn" onClick={() => { setLocOpen((o) => !o); setOpen(false); }}>
                {locVal ? (locale === "ar" ? locVal.ar : locVal.en) : tr.search.location}
              </button>
              <Icon name="chevron-down" className="sb-loc-caret" />
            </div>
            <button className="btn btn-primary sb-go" onClick={() => go({ name: "listing", category: null })}>
              <Icon name="search" />{tr.search.cta}
            </button>
          </div>

          {locOpen ? (
            <div className="loc-pop">
              <div className="loc-countries">
                {D.countries.map((c) => (
                  <button key={c.code} className={"loc-country" + (c.active ? " on" : " soon")} disabled={!c.active}>
                    {c[locale]}{!c.active ? <span className="soon-pill">{tr.locp.soon}</span> : null}
                  </button>
                ))}
              </div>
              <div className="loc-group">
                <div className="sb-grouphead"><Icon name="building" />{tr.locp.popularCities}</div>
                <div className="loc-chips">
                  {D.omanCities.map((c, i) => (
                    <button key={i} className={"loc-chip" + (selCity && selCity.en === c.en ? " on" : "")}
                      onClick={() => { const ar = D.cityAreas[c.en]; if (ar && ar.length) { setSelCity(c); } else { setLocVal(c); setLocOpen(false); setSelCity(null); } }}>
                      {c[locale]}
                    </button>
                  ))}
                </div>
              </div>
              {selCity ? (
                <div className="loc-group">
                  <div className="sb-grouphead"><Icon name="map-pin" />{tr.locp.areas} · {selCity[locale]}</div>
                  <div className="loc-chips">
                    <button className="loc-chip" onClick={() => { setLocVal(selCity); setLocOpen(false); setSelCity(null); }}>{tr.locp.use} {selCity[locale]}</button>
                    {(D.cityAreas[selCity.en] || []).map((a, i) => (
                      <button key={i} className="loc-chip" onClick={() => { setLocVal({ en: a.en + " · " + selCity.en, ar: a.ar + " · " + selCity.ar }); setLocOpen(false); setSelCity(null); }}>{a[locale]}</button>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          ) : null}

          {open ? (
            <div className="sb-drop">
              {query === "" ? (
                <React.Fragment>
                  <div className="sb-group">
                    <div className="sb-grouphead"><Icon name="layout-grid" />{tr.search.quickLabel}</div>
                    <div className="sb-pop">
                      {D.quickCats.map((c, i) => (
                        <button key={i} className="sb-popchip" onClick={() => choose(c.route)}>
                          <Icon name={c.icon} />{locale === "ar" ? c.ar : c.en}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="sb-group">
                    <div className="sb-grouphead"><Icon name="trending-up" />{tr.search.popular}</div>
                    <div className="sb-pop">
                      {D.popular[locale].map((p, i) => (
                        <button key={i} className="sb-popchip" onClick={() => choose({ name: "listing", category: null })}>
                          <Icon name="search" />{p}
                        </button>
                      ))}
                    </div>
                  </div>
                </React.Fragment>
              ) : grouped.length ? (
                grouped.map((g) => (
                  <div className="sb-group" key={g.tp}>
                    <div className="sb-grouphead">{groupLabel[g.tp]}</div>
                    {g.items.map((it) => {
                      flatIdx++;
                      const active = flatIdx === hi;
                      return (
                        <button key={it.en + it.type} className={"sb-item" + (active ? " active" : "")}
                          onMouseEnter={() => setHi(flat.indexOf(it))}
                          onClick={() => choose(it.route)}>
                          <span className="sb-item-ic"><Icon name={typeIcon[g.tp]} /></span>
                          <span className="sb-item-label">{locale === "ar" ? it.ar : it.en}</span>
                          <Icon name="arrow-up-right" className="sb-item-go" />
                        </button>
                      );
                    })}
                  </div>
                ))
              ) : (
                <div className="sb-empty">
                  <Icon name="search-x" />
                  <span>{tr.search.noResults}</span>
                </div>
              )}
            </div>
          ) : null}
        </div>

        <div className="sb-chips">
          <span className="sb-chips-lbl">{tr.search.browse}</span>
          <div className="chips">
            {D.categories.map((c) => (
              <span key={c.key} className="chip" onClick={() => go({ name: "listing", category: c.key })}>
                <Icon name={c.icon} />{c[locale]}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Featured centers carousel (fade rotation, RTL-safe) ---------------- */
function FeaturedCarousel({ tr, locale, go }) {
  const D = window.DM_DATA;
  const items = D.featuredIds.map((id) => D.providers.find((p) => p.id === id)).filter(Boolean);
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const n = items.length;

  useEffect(() => {
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || paused) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % n), 5000);
    return () => clearInterval(t);
  }, [paused, n]);

  const goTo = (i) => setIdx((i + n) % n);
  const p = items[idx];
  const name = locale === "ar" ? p.ar : p.en;
  const area = locale === "ar" ? p.area.ar : p.area.en;
  const hours = locale === "ar" ? p.hoursAr : p.hoursEn;
  const desc = locale === "ar" ? p.descAr : p.descEn;
  const prevIcon = locale === "ar" ? "chevron-right" : "chevron-left";
  const nextIcon = locale === "ar" ? "chevron-left" : "chevron-right";

  return (
    <div className="featured" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="featured-head">
        <div>
          <div className="eyebrow">{tr.featured.eyebrow}</div>
          <h2>{tr.featured.title}</h2>
        </div>
        <div className="featured-nav">
          <button className="rnd-btn" onClick={() => goTo(idx - 1)} aria-label="Previous"><Icon name={prevIcon} /></button>
          <button className="rnd-btn" onClick={() => goTo(idx + 1)} aria-label="Next"><Icon name={nextIcon} /></button>
        </div>
      </div>

      <div className="fc-card" key={idx}>
        <div className="fc-media">
          <span className="fc-media-ic"><Icon name="image" /></span>
          <span className="fc-tag"><Icon name="eye" />{tr.featured.badge}</span>
        </div>
        <div className="fc-body">
          <div className="fc-cat">{provCat(p, locale)}</div>
          <h3 onClick={() => go({ name: "provider", id: p.id })}>{name}</h3>
          <div className="fc-metas">
            <span className="meta"><Icon name="map-pin" />{area} · {tr.search.location.split(",")[0]}</span>
            <span className="meta"><Icon name="clock" />{hours}</span>
          </div>
          <p className="fc-desc">{desc}</p>
          <div className="fc-actions">
            <Btn variant="primary" size="sm" icon="arrow-up-right" onClick={() => go({ name: "provider", id: p.id })}>{tr.cta.viewProfile}</Btn>
            <Btn variant="whatsapp" size="sm" icon="message-circle">{tr.cta.whatsapp}</Btn>
            <Btn variant="secondary" size="sm" icon="phone">{tr.cta.call}</Btn>
            <Btn variant="secondary" size="sm" icon="navigation">{tr.cta.directions}</Btn>
          </div>
        </div>
      </div>

      <div className="fc-dots">
        {items.map((_, i) => (
          <button key={i} className={"fc-dot" + (i === idx ? " on" : "")} onClick={() => goTo(i)} aria-label={"Slide " + (i + 1)}></button>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Rich category grid (scalable discovery system) ---------------- */
function RichCategoryGrid({ tr, locale, go }) {
  const D = window.DM_DATA;
  return (
    <div className="container">
      <SectionHead eyebrow={tr.cat.eyebrow} title={tr.cat.title} sub={tr.cat.sub} />
      <div className="rcat-grid">
        {D.richCategories.map((c, i) => (
          <button key={i} className="rcat" onClick={() => go({ name: "listing", category: c.route })}>
            <span className="rcat-ic"><Icon name={c.icon} /></span>
            <span className="rcat-text">
              <span className="rcat-title">{c[locale]}</span>
              <span className="rcat-desc">{locale === "ar" ? c.dAr : c.dEn}</span>
            </span>
            <span className="rcat-explore">{tr.cat.explore}<Icon name={locale === "ar" ? "arrow-left" : "arrow-right"} /></span>
          </button>
        ))}
      </div>
      <div className="sec-note"><Icon name="info" />{tr.cat.note}</div>
    </div>
  );
}

/* ---------------- Browse by area ---------------- */
function AreaSection({ tr, locale, go }) {
  const D = window.DM_DATA;
  return (
    <div className="container">
      <SectionHead eyebrow={tr.areasSec.eyebrow} title={tr.areasSec.title} sub={tr.areasSec.sub} />
      <div className="area-grid">
        {D.areas.map((a, i) => (
          <button key={i} className="area-card" onClick={() => go({ name: "listing", category: null })}>
            <span className="area-top">
              <span className="area-name"><Icon name="map-pin" />{a[locale]}</span>
              <Icon name="arrow-up-right" className="area-go" />
            </span>
            <span className="area-meta">
              <span className="area-count">~{a.count} {tr.areasSec.places}</span>
              <span className="area-dot">·</span>
              <span className="area-hint">{locale === "ar" ? a.hintAr : a.hintEn}</span>
            </span>
          </button>
        ))}
      </div>
      <div className="sec-note"><Icon name="info" />{tr.areasSec.note}</div>
    </div>
  );
}

/* ---------------- Trust & safety ---------------- */
function TrustSection({ tr, locale }) {
  return (
    <div className="container">
      <SectionHead eyebrow={tr.trust.eyebrow} title={tr.trust.title} sub={tr.trust.sub} />
      <div className="trust-grid">
        {tr.trust.items.map((it, i) => (
          <div className="trust-item" key={i}>
            <span className="trust-ic"><Icon name={it.icon} /></span>
            <h3>{it.t}</h3>
            <p>{it.b}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { SearchBox, FeaturedCarousel, RichCategoryGrid, AreaSection, TrustSection });
