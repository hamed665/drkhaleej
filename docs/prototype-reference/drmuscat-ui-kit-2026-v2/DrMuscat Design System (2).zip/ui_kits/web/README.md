# DrMuscat — Web UI Kit

High-fidelity, interactive recreation of the DrMuscat web experience. Open `index.html` — it boots an
interactive click-through with a real **EN ⇄ AR (LTR ⇄ RTL)** toggle in the header.

> This is a UI kit, not production code: interactions are cosmetic (search doesn't query, "Call"/"WhatsApp"
> are placeholders, the listing form submits nothing). The goal is pixel-level visual + interaction fidelity
> and clean, reusable components for handoff into a scoped Next.js frontend.

## Run it
Just open `index.html`. It loads:
- `../../colors_and_type.css` — design tokens (colors, type, spacing, radii, shadows)
- `styles.css` — kit styles (RTL-aware via CSS logical properties)
- React 18 + Babel (in-browser) + Lucide (icons) from CDN
- `data.js` → `components.jsx` → `cards.jsx` → `pages.jsx` → `pages2.jsx` → `app.jsx`

## What's inside

**Surfaces (interactive):**
- **Homepage** — search-first discovery. Order: hero + **powerful search with grouped autocomplete** (above the fold) → **featured-centers carousel** → scalable **category grid** (15 categories) → **browse-by-area** (12 Muscat areas) → **trust & safety** → newly-added providers (sample) → "List your center" band.
- **Listing / category page** — breadcrumb, title, the same autocomplete search (compact), area filter sidebar (mobile = scrollable chips), result grid, count, empty/no-results state, clear-filters.
- **Provider detail** — summary hero, contact actions, About, Services & info, Practical information, Gallery placeholders, sticky contact aside + map placeholder + trust notice, related providers, mobile sticky contact bar.
- **For Providers** — value-prop hero, benefits, how-it-works steps, request-listing form (placeholder).

**Discovery components** (`discovery.jsx`):
- **`SearchBox`** — large search input + location selector + Search button, with a live **autocomplete dropdown** that filters a UI-only suggestion index and groups results into **Categories / Providers / Services & specialties / Areas**. States: popular-searches (empty query), grouped suggestions (typing), no-results, keyboard navigation (↑/↓/Enter/Esc), click-outside-to-close. Filters in both English and Arabic. `variant="compact"` is used on the listing page.
- **`FeaturedCarousel`** — rotating featured center (5–10 supported, 7 demo). Auto-advances every 5s, pauses on hover, respects `prefers-reduced-motion`; prev/next (flipped for RTL) + dots. Each slide: media placeholder, category, name, area, hours, description, **Call / WhatsApp / View profile**.
- **`RichCategoryGrid`** — scalable visual category system (15 cards: Doctors, Clinics & Centers, Hospitals, Pharmacies, Laboratories, Dental, Beauty, Wellness, Physiotherapy, Nutrition, Eye, Dermatology, Pediatrics, Women's health, Pet clinics). Each routes to a canonical category. Demo counts are clearly labelled as sample placeholders.
- **`AreaSection`** — 12 Muscat areas with demo count + popular-category hint (sample placeholders).
- **`TrustSection`** — four calm trust/safety points (clear info, no fake metrics, bilingual, Oman-focused).

> **Routes vs. visual categories:** the production **nav** uses only the six canonical routes
> (Doctors · Centers · Pharmacies · Labs · Services · Search). The richer homepage category grid is a *scalable
> visual system* — each tile maps onto a canonical route for now; new routes can be added safely later.

**Core components** (`components.jsx`, `cards.jsx`):
`Icon`, `Brand`, `Btn` (primary/secondary/ghost/gold + sizes), `Header` (nav + locale switch + mobile drawer),
`Footer` (5 columns + contact line), `CategoryCard`, `SectionHead`, `ProviderCard` (media, name, category, area,
hours, description, service/language tags, **Call / WhatsApp / View profile**), `EmptyState`.

## Bilingual / RTL rules baked in
- One harmonized family (**Readex Pro**) for both languages.
- `dir` is set on `<html>` and `.app`; layout uses **logical properties** (`margin-inline`, `inset-inline`,
  `text-align: start`) so it mirrors correctly — not a naïve flip.
- Arabic drops uppercase eyebrows/letter-spacing, uses a slightly larger line-height and a **smaller** hero size
  so headings don't shout. Arabic screens contain **no English nav** — only the language switch (which reads
  "English").
- Directional icons (chevrons, navigation) flip under RTL; symbolic icons don't.

## Data & integrity (`data.js`)
- Canonical categories only: **Doctors · Centers · Pharmacies · Labs · Services · Search**.
- Sample providers are **neutral placeholders** — real Muscat neighbourhoods, plausible names, factual fields
  (category, area, listed hours, services, languages, insurance). **No** ratings, reviews, counts, "top doctor",
  live availability, or sponsored blocks anywhere.
- **No "Verified" badge** — it could imply real verification. The carousel uses a neutral **"Featured sample"**
  tag; the providers section is labelled **"Provider profile previews / sample cards, not real listings"**.
- Category tiles show a neutral **"Explore"** action (no fabricated counts). Area cards show a clearly-marked
  **`~` sample count** plus a popular-care hint, with a "sample placeholders" note.

## Responsive behaviour
Fluid across **320 → 1920px**; verified at the common phone/tablet/laptop widths. No horizontal scroll; Arabic
never clipped.
- **Desktop / laptop (≥1024):** hero + search above the fold; 5-col category grid, 4-col areas, 4-col trust,
  3-col provider grid, side-by-side carousel card; full nav.
- **Tablet (768–1024):** 3-col categories/areas, 2-col trust, 2-col provider grid; nav collapses to a drawer at
  ≤860; carousel media shrinks then stacks.
- **Mobile (≤640):** order is header → short hero → **search panel (immediately, minimal scroll)** → quick chips
  → carousel (stacked card: media on top, body below, arrows + dots) → categories (2-col, 1-col ≤380) → areas
  (2-col) → trust (1-col) → provider previews → for-providers → footer. Search row stacks (input / location /
  full-width button); chips wrap; sticky contact bar appears on provider detail.

## Handoff notes
- Each page maps cleanly to a Next.js route/component; `data.js` is the single content/i18n source to replace
  with real data + an i18n layer.
- Heading hierarchy is SEO-safe: one `<h1>` per surface, logical `h2/h3` nesting, crawl-friendly nav labels,
  no hidden text or keyword stuffing.
- Touch targets ≥ 44px on mobile; visible focus rings; `prefers-reduced-motion` respected.
- Swap the in-browser Babel + CDN React for a real build; swap Lucide-CDN for a bundled icon import.

## Button system (visual hierarchy)
| Tier | Buttons | Style | States |
|---|---|---|---|
| **Primary** | Search · View profile · List your center | solid teal `--teal-700`, white text | hover → teal-800, active → teal-900 + 0.5px nudge, focus → 3px teal ring, disabled → grey |
| **Contact (WhatsApp)** | WhatsApp | solid muted green `#1FA458`, white text, `message-circle` icon | hover `#178A49`, active `#127A40` — deliberately distinct from the teal brand so it reads as "message" |
| **Secondary** | Call · Directions | white + teal hairline (`btn-secondary`) | hover → teal-50 + stronger border |
| **Ghost / outline** | filters, category chips, language switch, "Open map" | transparent / hairline | hover → teal-50 |
| **Accent** | Request listing (on dark) | gold `#C9A24B` | used sparingly on dark panels only |

- **Icon-only variant** (`IconBtn`, `.btn-icon`, 40–44px square) is used for Call / Directions inside compact
  cards, with a `title`/`aria-label`. Full label version is used wherever there's room (carousel, profile, aside).
- **Standard provider-card actions:** primary **View profile** (full width) + a contact row of **WhatsApp
  (labelled, green) / Call (icon) / Directions (icon)**. Never all-equal weight.
- **WhatsApp icon:** Lucide has no brand glyph, so a green `message-circle` is used. **Swap in the official
  WhatsApp mark in production.**

## Icon system (Lucide, 1.75px stroke)
`search` · `map-pin` (location/area) · `phone` (call) · `message-circle` (WhatsApp) · `navigation` (directions) ·
`map` / `external-link` (open map) · `clock` (hours) · `globe` (language) · `building-2`/`stethoscope`/`pill`/
`flask-conical`/`heart-pulse` (categories) · `badge-check`→removed (no verification) · `layout-grid`/`filter`/
`sliders-horizontal` (filters) · `arrow-up-right`/`chevron-*` (nav, flipped in RTL). Directional icons mirror
under RTL; symbolic icons don't.

## Page flow & connections
- **Homepage:** search → search results · category chip / category card → category listing · featured card /
  provider preview → provider profile · area card → area listing · "List your center" → For Providers.
- **Search results / category listing:** result card → provider profile · category switch chips → category
  results · area filter → area results · search bar → updated results.
- **Provider profile:** WhatsApp / Call / Directions → contact actions (design placeholders) · related provider →
  another profile · breadcrumb → category / home.
- **For Providers:** Request listing / Claim your profile / Talk to us → lead-form placeholder · How it works /
  Trust & safety → on-page sections.

## Route inventory (documentation only — no real routing built)
Conceptual locale-prefixed paths a Next.js implementation could adopt. The kit's internal router is a simple
state machine (`{name, category, id}`); these slugs are the intended public URLs.

| Page | English | Arabic |
|---|---|---|
| Home | `/en/om` | `/ar/om` |
| Search | `/en/om/search` | `/ar/om/search` |
| Doctors | `/en/om/doctors` | `/ar/om/doctors` |
| Centers | `/en/om/centers` | `/ar/om/centers` |
| Pharmacies | `/en/om/pharmacies` | `/ar/om/pharmacies` |
| Labs | `/en/om/labs` | `/ar/om/labs` |
| Services | `/en/om/services` | `/ar/om/services` |
| Area listing | `/en/om/areas/al-khuwair` | `/ar/om/areas/al-khuwair` |
| Provider profile | `/en/om/providers/al-khuwair-medical-centre` | `/ar/om/providers/al-khuwair-medical-centre` |
| For Providers | `/en/om/for-providers` | `/ar/om/for-providers` |

The richer homepage category tiles (Dental, Pet clinics, etc.) map onto the canonical category routes above for
now; dedicated routes can be added safely later without changing the visual system.

## Accounts, onboarding & dashboards (design-only — no real auth/OTP/OAuth/payment)
`auth.jsx` + `dashboard.jsx` + `data2.js` add the full account layer. **No backend, no Supabase, no real OTP /
Google OAuth, no real payment** — every action is a UI placeholder.

**Sign in / Register** (`/en/om/signin`, `/register`): Continue with Google · Continue with phone · Continue as
guest (sign-in only). **Phone OTP** (enter number → 6-box code → resend / change number). **Google** → connected
→ continue. Then **account type** → role-aware **profile setup** → dashboard.

**Account types → dashboard role** (`data2.js` `accountTypes`):
care→user · doctor→doctor · clinic/center→center · pharmacy→pharmacy · laboratory→lab · beauty/wellness→beauty ·
pet/vet→pet · marketer→marketer · other→provider.

**Dashboard shell** (`/en/om/dashboard`): one config-driven shell (`roleConfig`) renders a role-specific sidebar +
topbar with a **Preview role** switcher (so reviewers can see every role without re-registering) and a persistent
"design preview — sample data" banner. Panels: **Overview** (role-aware: user = saved/searches/areas empty
states; provider = profile-completion + status `draft/pending/live/rejected` + sample stats + profile preview +
verification + plan teaser; marketer = assigned/onboarding/follow-ups/commission + sample leads), **Profile,
Listings, Doctors/Team, Services, Schedule, Gallery, Offers, Leads, Verification, Subscription & billing,
Settings, Help** (role-specific subset).

**Subscription & billing (future placeholders):** plan cards — **Free listing · Verified starter · Growth partner
· Premium visibility · Ads/featured (future)** — current-plan tag, billing-history empty state, payment-method
note, and payment-state concepts (Pending / Paid / Failed / Ad credits·Future), all under the banner *"Plans and
payments are not finalised yet."* No pricing is shown as confirmed.

**Claim flow** (`/en/om/claim`): 5-step stepper — find profile → confirm ownership → phone OTP → optional
document upload (placeholder) → submitted (pending review).

**Request a listing** (on For Providers): phone-first, email optional, with provider type, country/city/area,
contact person, WhatsApp, ownership y/n, preferred language — plus a submitted / pending-review success state.

## Location model
`SearchBox` location picker: **country** selector (Oman active; UAE / Saudi Arabia / Qatar / Bahrain / Kuwait
shown as "Soon"), then Oman **cities/governorates** (Muscat, Seeb, Bausher, Muttrah, Amerat, Quriyat, Sohar,
Salalah, Nizwa, Sur, Ibri, Buraimi, Rustaq, Ibra, Khasab, Duqm) and **Muscat areas**. Oman is the default active
country.

## Full route inventory (public + console)
| Area | English | Arabic |
|---|---|---|
| Sign in | `/en/om/signin` | `/ar/om/signin` |
| Register | `/en/om/register` | `/ar/om/register` |
| OTP verify | (step within auth) | (step within auth) |
| Claim profile | `/en/om/claim` | `/ar/om/claim` |
| User dashboard | `/en/om/dashboard` | `/ar/om/dashboard` |
| Doctor dashboard | `/en/om/dashboard/doctor` | `/ar/om/dashboard/doctor` |
| Center dashboard | `/en/om/dashboard/center` | `/ar/om/dashboard/center` |
| Pharmacy dashboard | `/en/om/dashboard/pharmacy` | `/ar/om/dashboard/pharmacy` |
| Lab dashboard | `/en/om/dashboard/lab` | `/ar/om/dashboard/lab` |
| Beauty/wellness dashboard | `/en/om/dashboard/beauty` | `/ar/om/dashboard/beauty` |
| Pet clinic dashboard | `/en/om/dashboard/pet` | `/ar/om/dashboard/pet` |
| Marketer dashboard | `/en/om/dashboard/marketer` | `/ar/om/dashboard/marketer` |
| Billing / subscription | `/en/om/dashboard/billing` | `/ar/om/dashboard/billing` |
| Settings | `/en/om/dashboard/settings` | `/ar/om/dashboard/settings` |

## Role → post-registration flow map
- **User** → dashboard: saved providers · recent searches · preferred areas · settings.
- **Doctor** → dashboard: profile (completion + status) · clinics & affiliations · services · schedule · leads ·
  verification · billing. Public **doctor profile** adds specialty/sub-specialty/experience/education (sample-tagged)
  + **Request appointment**.
- **Center / Pharmacy / Lab / Beauty / Pet / Other** → dashboard: profile + status · services (or tests) ·
  schedule/gallery/offers as relevant · leads · verification · billing. Entry points: **Request a listing** or
  **Claim profile** → pending review.
- **Marketer** → dashboard: assigned providers · onboarding · follow-ups · territory · commission · payouts
  (all placeholders) · pending-approval banner.

## Final product-architecture pass (this round)
All design-only. No real auth/OTP/OAuth/password store/payment/WhatsApp API/AI/CMS/upload/subdomain routing.

**Auth (expanded)** — Sign in / Register support **Google · phone OTP · email-or-phone + password · guest**.
Password screens: sign-in-with-password, optional create-password on register (+ confirm), **forgot password**
→ reset-sent confirmation. (`auth.jsx`.)

**Simplified registration** — Step 1 method → Step 2 **three** main types (Looking for care / Healthcare-provider
business / Marketer). Only "provider business" reveals **Step 2b provider type** (Doctor, Clinic/center, Pharmacy,
Lab, Beauty/wellness, Pet/vet, Hospital, Other) → role-aware profile setup. **Admin / Super Admin are
internal/invited only** — never public-selectable.

**Location — Country → City → Area (three separate, dependent levels)** — Country, City and Area are **distinct
controls**, never mixed: the City dropdown lists only cities/governorates (Muscat, Seeb, Bausher, Muttrah,
Salalah, Sohar, …) and the Area dropdown shows only that **selected city's** neighbourhoods (`data2.js`
`cityAreas` maps Muscat / Seeb / Bausher / Muttrah / Salalah / Sohar; unmapped cities fall back to "Not sure /
add later" rather than showing wrong areas). Country: Oman active; UAE / Saudi Arabia / Qatar / Bahrain / Kuwait /
Iran are disabled "— Soon" options. The reusable **`LocationSelect`** component (in `components.jsx`) is the single
source for this in profile setup, request-listing, dashboard profile editors and admin location management; the
homepage `SearchBox` picker uses the same model. Labels: Country / City / Area · الدولة / المدينة / المنطقة. Same model is the intended source for
search, registration, onboarding, request-listing, claim, and admin location management.

**Articles / blog (first-class, SEO candidate)** — `articles.jsx`: index (featured + category filter + search +
latest grid + "from providers & doctors"), detail (hero / YouTube-embed placeholder, byline, table of contents,
inline figure, related providers + related articles, general-info disclaimer — **no medical claims/reviews**), and
a calm homepage "Health guides" band. 10 categories in `data2.js`.

**Global floating support** (`fab.jsx`) — stacked **WhatsApp** (green) + **Ask AI** buttons on public pages;
label-on-hover pills; AI panel opens with the safety welcome ("…I cannot provide medical diagnosis"), quick
chips, input, and a placeholder note. Raises above the provider mobile sticky bar; respects safe-area; reduced-
motion friendly.

**Form system fix** — all inputs/selects are `width:100%; min-width:0; box-sizing:border-box` and grid children
get `min-width:0`, so 2-col forms collapse cleanly to 1-col and **nothing overflows the card**; RTL select arrow
flips side. Applied across auth, setup, request-listing, claim, dashboard, settings.

**Provider plans & feature matrix** — Billing panel shows the 5 plan cards **plus a Compare-plans matrix**
(`data2.js` `planMatrix`: profile, listing, verified status, gallery, contact buttons, offers, leads/analytics,
articles, featured eligibility, subdomain × Free/Starter/Growth/Premium). Under the *"not finalised"* banner.

**Plans → feature gating (design intent):** Free = basic profile/listing only. Verified Starter = review-gated
verified status + gallery + contact buttons + basic analytics. Growth Partner = offers, lead tracking, analytics
charts, article submission, team management. Premium Visibility = featured-placement eligibility, premium layout,
ads dashboard, subdomain/microsite. **Ads / Featured** = paid promotion add-on. Dashboard items intended to carry
**Available / Locked / Upgrade-required / Pending-review / Requires-approval** states.

**Admin & Super Admin** (preview via dashboard role switcher) —
- **Admin:** overview (queues) · providers · claim requests · listing requests · verification queue · articles /
  media / offers / ads review · leads · messages · payments · reports · users · settings. Actions: approve /
  reject / request-changes / suspend / archive / message / assign / mark-paid / status / internal note.
- **Super Admin:** overview · roles & permissions · admins · plans · locations · categories · ads · SEO controls ·
  translations · audit log · system health · platform settings.
- Both are **private, noindex, internal** — not in public nav/SEO.

**Permission matrix (design intent):** Super Admin > Admin > Content Manager · Medical Reviewer · Finance Manager ·
Sales/Marketer (internal) ; Provider Owner > Manager > Staff / Doctor / Content editor / Finance contact (per
account) ; Normal User (public). High-risk actions (plans, ad pricing, role changes, overrides, suspensions) are
Super-Admin-gated.

**Approval workflow** — every provider-submitted item (profile, edits, photos, video, offers, articles, ads,
featured, subdomain, claim, license) moves through **draft → submitted → pending review → needs changes →
approved → published/live → rejected → archived → suspended**, surfaced in provider dashboard + admin + super-admin.

**Offers / packages, Media, Ads, Subdomain, Team, Support (design intent — representative panels + docs):**
- *Offers:* provider create/edit → submit → admin approve; public "offers" section on profiles; no fake discounts.
- *Media:* cover + gallery (4–8 clinic / 1–3 doctor), YouTube embed, alt-text/caption/credit placeholders, per-item
  approval status; admin media queue with missing-alt / unsafe-image warnings.
- *Ads/featured:* choose placement (home carousel / category / area / search-sponsored / banner / profile boost) →
  target → duration → budget placeholder → preview → submit → admin approval → active → report.
- *Subdomain/microsite:* `alkhuwairmedical.drmuscat.com` style — request → pending → active/rejected; premium
  microsite layout (hero/services/team/offers/articles/gallery/video/contact/map). No real DNS.
- *Team:* center adds/invites staff & doctors (owner/manager/staff/doctor/content-editor/finance roles); doctors
  request/accept affiliation. Multi-role users get a role switcher.
- *Support:* provider ↔ admin messages/tickets (open / waiting-provider / waiting-admin / resolved / closed).

**Analytics (design intent):** providers — profile views, WhatsApp/call/directions clicks, leads, search
appearances, top services/terms/areas, offer & article & ad performance. Marketer — pipeline & commission.
Admin — approvals/claims/leads/growth/search trends. Super Admin — growth, revenue, plan distribution, system
health. (Charts are placeholders; no fabricated numbers presented as real — sample values are pill-tagged.)

**Billing/payments (future placeholder):** subscriptions, one-time featured, ads wallet, manual + online-gateway
placeholders, invoices, statuses (pending/paid/failed/expired), upgrade/downgrade/cancel. Default currency **OMR**.
No live payment implied.

**Language switch** preserves the equivalent route (`/en/om/...` ⇄ `/ar/om/...`) — English slugs for both
languages; only falls back to home when no equivalent exists. Root `/` → `/en/om`.

## Full URL map (public · dashboard · admin · super-admin)
English slugs under both `/en/om/...` and `/ar/om/...`.
- **Public (indexable candidates):** `/`(→`/en/om`) · `/search` · `/doctors` · `/centers` · `/pharmacies` ·
  `/labs` · `/services` · category pages `/categories/[slug]` · `/areas/[area-slug]` · `/providers/[slug]` ·
  `/doctors/[doctor-slug]` · `/articles` · `/articles/[slug]` · `/articles/categories/[slug]` · `/for-providers` ·
  `/about` · `/contact` · `/help` · `/privacy` · `/terms` · `/accessibility`.
- **Auth / account (noindex):** `/sign-in` · `/register` · `/verify-otp` · `/onboarding/account-type` ·
  `/for-providers/request-listing` · `/for-providers/claim-profile` · `/account` · `/account/saved` ·
  `/account/settings`.
- **Dashboard (private):** `/dashboard/{user,doctor,center,pharmacy,lab,wellness,pet-clinic,marketer}` +
  `/dashboard/{profile,listings,leads,verification,billing,settings}`.
- **Admin (private):** `/admin/{overview,providers,doctors,claims,listing-requests,leads,messages,ads,payments,
  content,articles,offers,media,reports,users,settings}`.
- **Super Admin (private):** `/super-admin/{overview,roles,admins,audit-log,billing,platform-settings,seo-controls,
  system-health,locations,categories,plans}`.

## SEO visibility (design intent — no SEO files built)
**Indexable later:** home, category pages, area pages, articles, **approved** provider & doctor profiles.
**Noindex / private:** dashboards, account, auth/OTP, billing, request-listing & claim forms, incomplete profiles,
admin, super-admin, design-preview surfaces. One `<h1>` per page; logical `h2/h3`; clean breadcrumbs; no hidden
text / keyword stuffing / fake reviews / fake counts (sample values are explicitly pill-tagged).

## Implemented vs. documented-only
**Built & interactive:** all public pages incl. articles + floating support; the expanded auth/onboarding; the
dependent location picker; the request-listing & claim flows; the role-switchable dashboard shell (incl. admin /
super-admin overviews) with billing + plan matrix; the form-overflow fix; the WhatsApp/Call/Directions hierarchy.
**Representative placeholder panels (structure, not full UI):** media manager, offers manager, ads/featured buying,
analytics charts, team management, support tickets, subdomain request, and the deep admin/super-admin sub-screens —
each documented above as intended structure/flow/states for the build.

## FAQ, reviews & comments (this round)
**FAQ (SEO/GEO-ready accordion, `social.jsx` `FAQ` + `data2.js` `faqs`)** — calm Q&A on homepage, category/listing,
provider profiles and article detail; sets exist for home/provider/article/category (EN+AR). Single-open accordion,
"not medical advice" subhead. Structured so a build can attach FAQ structured data later — **no schema files here.**

**Reviews & ratings (`ReviewsBlock`) — honest by design.** Shown on provider & doctor profiles: rating summary that
reads **"No ratings yet"** (never a fabricated number), a **Write a review** flow (star input + text → "Pending
moderation"), disabled sort/filter affordances, an empty state, and a visible moderation/trust note. Intended
statuses: draft → submitted → pending moderation → published → rejected → hidden → reported → removed. Rules baked
into copy: **no fake reviews/ratings, no pre-filled "best doctor", reviews are moderated, misinformation is
reportable/removable, providers may respond but not delete criticism, Super Admin overrides.**

**Comments (`CommentsBlock`)** — on article detail: empty state + add-comment box → pending moderation + note. Same
no-misinformation / moderated stance.

## Expanded URL map (offers, account, faq + full dashboard/admin/super-admin)
Adds to the map above (English slugs under both `/en/om` and `/ar/om`):
- **Public:** `/offers` · `/offers/[offer-slug]` · `/faq` · `/articles/categories/[category-slug]`.
- **Account:** `/forgot-password` · `/reset-password` · `/onboarding/profile` · `/account/reviews` ·
  `/account/comments`.
- **Provider dashboard:** `/dashboard/{overview,profile,services,media,offers,articles,reviews,leads,analytics,ads,
  billing,team,verification,messages,settings}`.
- **Admin:** `/admin/{overview,users,providers,doctors,listing-requests,claims,verification,media,offers,articles,
  faqs,reviews,comments,reports,ads,featured,leads,messages,billing,plans,locations,categories,translations,seo,
  settings}` — admin can approve/reject/request-changes/publish/unpublish/hide/suspend/archive/restore/feature/
  assign/respond/note/verify/moderate across all of it.
- **Super Admin:** `/super-admin/{overview,platform-settings,roles,admins,permissions,plans,billing,ads-settings,
  featured-settings,homepage-modules,locations,categories,seo-geo,review-policy,integrations,audit-log,
  system-health}`.

## SEO / GEO-ready structure (design intent — no SEO/schema files built)
One `<h1>` per page; logical `h2/h3`; breadcrumbs on listing/provider/article. Category & area landing pages carry
intro + filters + provider cards + related categories/areas/articles + **FAQ** + provider CTA + safety disclaimer
(internal-linking blocks for crawl + GEO answer surfaces). Provider/doctor profiles expose structured sections
(services, team, hours, location, offers, articles, **reviews**, FAQ, related/nearby). Canonical + hreflang intent:
English slugs for both languages, `/en/om/…` ⇄ `/ar/om/…` alternate. Indexable later: home, categories, areas,
articles, **approved** provider/doctor profiles. Noindex: dashboards, admin, super-admin, auth/OTP, account,
billing, request/claim forms, incomplete profiles, design-preview. No keyword stuffing, no fake ratings/reviews,
no fake counts (sample values are pill-tagged); reviews display only after moderation.

## Onboarding, ratings, nearby & profile actions (this round)
- **Account type** is one clean flat step ("What are you joining as?") with the 8 listed roles (care · doctor ·
  clinic/center · pharmacy · lab · wellness/beauty · pet clinic · marketer) → role-aware setup. Admin/Super Admin
  remain internal-only.
- **Location in onboarding** uses the shared `LocationSelect` (Country → City → Area, area depends on city) — City
  never shows neighbourhoods. Native selects get a custom caret (RTL-flipped) and stay inside the card.
- **Ratings — honest.** Provider & doctor cards and profiles show a star slot reading **"No reviews yet"** (never a
  fabricated ★/count) plus a **Verified** chip only when verified, and a factual **"Near {area}"** label. `ReviewsBlock`
  + `CommentsBlock` provide the moderated write flow ("Pending moderation"), empty states, and trust note;
  intended statuses draft→submitted→pending→published→rejected→hidden→reported→removed; providers may respond but
  not delete criticism; admin/super-admin moderate.
- **Nearby discovery (design placeholders, no real geolocation):** listing/search carry a bar with **Use my location**
  / **Choose area manually**, a **list/map toggle**, sort chips (Closest · Top rated · Open now · Verified only ·
  Insurance), and a "location is a placeholder" note. Cards use factual "Near {area}" rather than fake distances.
- **Profile actions:** hero = WhatsApp (green) · Call · Directions · Save · Share; aside = full-width WhatsApp/Call/
  Get directions + Open map; mobile sticky bar = WhatsApp · Call · Directions · Save. Aside also has **Claim this
  profile · Report incorrect info · Suggest an edit · Last updated** placeholders.
- **Admin/super-admin must later manage:** users, doctors/providers, onboarding submissions, listing & claim
  requests, country/city/area data, categories/specialties/services, reviews · ratings · comments · reports/flags
  (moderation queue), media/videos, offers, articles, FAQs, contact numbers, map/geo metadata, verification,
  featured placement, plans, profile completeness, provider/doctor responses, SEO/GEO fields, internal notes, audit
  log — documented as manageable fields, not built here.
