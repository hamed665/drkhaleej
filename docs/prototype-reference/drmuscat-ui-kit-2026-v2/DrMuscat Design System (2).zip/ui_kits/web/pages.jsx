/* DrMuscat kit — pages: Home + Listing */

function HomePage({ tr, locale, go }) {
  const D = window.DM_DATA;
  const newly = ["p9", "p11", "p10"].map((id) => D.providers.find((p) => p.id === id)).filter(Boolean);
  return (
    <main>
      {/* Search-first hero — search visible above the fold */}
      <section className="hero">
        <div className="hero-bg"></div>
        <div className="container hero-inner">
          <div className="eyebrow"><Icon name="map-pin" className="eb-pin" />{tr.search.location}</div>
          <h1 className="h-title">{tr.hero.title}</h1>
          <p className="lede">{tr.hero.sub}</p>
          <SearchBox tr={tr} locale={locale} go={go} />
        </div>
      </section>

      {/* Featured centers carousel */}
      <section className="section band-soft" style={{ paddingTop: 28 }}>
        <div className="container">
          <FeaturedCarousel tr={tr} locale={locale} go={go} />
        </div>
      </section>

      {/* Rich category grid */}
      <section className="section">
        <RichCategoryGrid tr={tr} locale={locale} go={go} />
      </section>

      {/* Browse by area */}
      <section className="section band-warm" style={{ paddingTop: 48 }}>
        <AreaSection tr={tr} locale={locale} go={go} />
      </section>

      {/* Health guides / articles — below the discovery sections, search stays first */}
      <section className="section">
        <HomeArticles tr={tr} locale={locale} go={go} />
      </section>

      {/* Trust & safety */}
      <section className="section band-soft">
        <TrustSection tr={tr} locale={locale} />
      </section>

      {/* Newly added providers (sample) */}
      <section className="section">
        <div className="container">
          <SectionHead
            eyebrow={tr.newly.eyebrow} title={tr.newly.title} sub={tr.newly.sub}
            action={<Btn variant="ghost" icon={locale === "ar" ? "chevron-left" : "chevron-right"} onClick={() => go({ name: "listing", category: null })}>{tr.newly.viewAll}</Btn>}
          />
          <div className="pgrid">
            {newly.map((p) => <ProviderCard key={p.id} p={p} tr={tr} locale={locale} go={go} />)}
          </div>
          <div className="sec-note"><Icon name="info" />{tr.newly.note}</div>
        </div>
      </section>

      {/* Homepage FAQ (SEO/GEO) */}
      <section className="section band-warm">
        <div className="container faq-narrow">
          <FAQ items={D.faqs.home[locale]} tr={tr} />
        </div>
      </section>

      {/* For providers band */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="fp-hero fp-band">
            <div>
              <div className="eyebrow">{tr.forProviders.eyebrow}</div>
              <h1 style={{ fontSize: 26, marginTop: 8 }}>{tr.forProviders.title}</h1>
              <p style={{ margin: "10px 0 0" }}>{tr.forProviders.sub}</p>
            </div>
            <Btn variant="gold" icon="arrow-right" onClick={() => go({ name: "forProviders" })}>{tr.cta.list}</Btn>
          </div>
        </div>
      </section>
    </main>
  );
}

function ListingPage({ tr, locale, go, page }) {
  const D = window.DM_DATA;
  const [area, setArea] = useState(null);
  const catKey = page.category;
  const cat = catKey ? D.categories.find((c) => c.key === catKey) : null;
  const title = cat ? cat[locale] : (locale === "ar" ? "كل المزودين" : "All providers");

  let list = D.providers.filter((p) => (catKey ? p.category === catKey : true));
  if (area) list = list.filter((p) => p.area.en === area);

  const reset = () => setArea(null);

  return (
    <main className="section">
      <div className="container">
        <div className="breadcrumb">
          <a onClick={() => go({ name: "home" })}>{tr.listing.breadcrumbHome}</a>
          <Icon name="chevron-right" />
          <span>{title}</span>
        </div>
        <div className="listing-head">
          <h1>{title} <span style={{ color: "var(--ink-400)", fontWeight: 400 }}>{tr.listing.resultsIn}</span></h1>
          <div className="loc"><Icon name="map-pin" />{tr.search.location}</div>
        </div>

        <div style={{ marginTop: 18 }}>
          <SearchBox tr={tr} locale={locale} go={go} variant="compact" />
        </div>

        {/* category switcher chips */}
        <div className="cat-switch chips" style={{ marginTop: 16 }}>
          <span className={"chip" + (!catKey ? " on" : "")} onClick={() => go({ name: "listing", category: null })}>
            {locale === "ar" ? "الكل" : "All"}
          </span>
          {D.categories.map((c) => (
            <span key={c.key} className={"chip" + (catKey === c.key ? " on" : "")} onClick={() => go({ name: "listing", category: c.key })}>
              <Icon name={c.icon} />{c[locale]}
            </span>
          ))}
        </div>

        {/* nearby / sort / filter discovery bar (design placeholders) */}
        <div className="near-bar">
          <div className="near-row">
            <button className="btn btn-secondary btn-sm" onClick={() => {}}><Icon name="locate-fixed" />{tr.near.useLoc}</button>
            <button className="btn btn-ghost btn-sm" onClick={() => {}}><Icon name="map-pin" />{tr.near.chooseArea}</button>
            <div className="near-toggle">
              <button className="on"><Icon name="list" />{tr.near.list}</button>
              <button><Icon name="map" />{tr.near.map}</button>
            </div>
          </div>
          <div className="near-chips chips">
            <span className="near-lbl">{tr.near.sortBy}</span>
            <span className="chip on"><Icon name="navigation" />{tr.near.closest}</span>
            <span className="chip"><Icon name="star" />{tr.near.rating}</span>
            <span className="chip"><Icon name="clock" />{tr.near.openNow}</span>
            <span className="chip"><Icon name="badge-check" />{tr.near.verifiedOnly}</span>
            <span className="chip"><Icon name="shield-check" />{tr.near.insurance}</span>
          </div>
          <div className="sec-note"><Icon name="info" />{tr.near.locNote}</div>
        </div>

        {/* mobile filter chips */}
        <div className="filter-mobile" style={{ marginTop: 16 }}>
          <span className={"chip" + (!area ? " on" : "")} onClick={() => setArea(null)}>{tr.listing.allAreas}</span>
          {D.areas.map((a) => (
            <span key={a.en} className={"chip" + (area === a.en ? " on" : "")} onClick={() => setArea(a.en)}>{a[locale]}</span>
          ))}
        </div>

        <div className="listing-layout">
          <aside className="filters">
            <h4>{tr.listing.area}</h4>
            <div className="filter-group">
              <div className={"filter-opt" + (!area ? " on" : "")} onClick={() => setArea(null)}>
                <span className="filter-radio"></span>{tr.listing.allAreas}
              </div>
              {D.areas.map((a) => (
                <div key={a.en} className={"filter-opt" + (area === a.en ? " on" : "")} onClick={() => setArea(a.en)}>
                  <span className="filter-radio"></span>{a[locale]}
                </div>
              ))}
            </div>
          </aside>

          <div>
            <div className="results-bar">
              <div className="count"><b>{list.length}</b> {tr.listing.places} {area ? ("· " + (D.areas.find(a => a.en === area)?.[locale])) : ""}</div>
              {area ? <Btn variant="ghost" size="sm" icon="x" onClick={reset}>{tr.listing.clear}</Btn> : null}
            </div>
            {list.length ? (
              <div className="pgrid">
                {list.map((p) => <ProviderCard key={p.id} p={p} tr={tr} locale={locale} go={go} />)}
              </div>
            ) : (
              <EmptyState tr={tr} onReset={reset} />
            )}
          </div>
        </div>

        <div className="faq-narrow" style={{ marginTop: 40 }}><FAQ items={D.faqs.category[locale]} tr={tr} /></div>
        <div className="fp-hero fp-band" style={{ marginTop: 24 }}>
          <div>
            <div className="eyebrow">{tr.forProviders.eyebrow}</div>
            <h2 style={{ fontSize: 22, marginTop: 8, color: "#fff", fontWeight: 600 }}>{tr.forProviders.title}</h2>
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <Btn variant="gold" icon="arrow-right" onClick={() => go({ name: "forProviders" })}>{tr.cta.list}</Btn>
            <button className="btn fp-outline" onClick={() => go({ name: "claim" })}>{tr.cta.claim}</button>
          </div>
        </div>
      </div>
    </main>
  );
}

Object.assign(window, { HomePage, ListingPage });
