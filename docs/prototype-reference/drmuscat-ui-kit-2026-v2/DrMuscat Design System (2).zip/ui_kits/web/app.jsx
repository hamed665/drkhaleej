/* DrMuscat kit — app shell: locale + RTL + simple page router */

function App() {
  const [locale, setLocale] = useState(() => localStorage.getItem("dm_locale") || "en");
  const [page, setPage] = useState({ name: "home" });
  const tr = window.DM_DATA.t[locale];
  const dir = tr.dir;

  const go = (next) => {
    setPage(next);
    window.scrollTo({ top: 0, behavior: "auto" });
  };
  const toggleLocale = () => {
    const nx = locale === "en" ? "ar" : "en";
    setLocale(nx);
    localStorage.setItem("dm_locale", nx);
  };

  // keep <html> dir/lang in sync (and refresh icons after each render)
  useEffect(() => {
    document.documentElement.setAttribute("dir", dir);
    document.documentElement.setAttribute("lang", locale);
  }, [dir, locale]);
  useEffect(() => { refreshIcons(); });

  let body;
  if (page.name === "home") body = <HomePage tr={tr} locale={locale} go={go} />;
  else if (page.name === "listing") body = <ListingPage tr={tr} locale={locale} go={go} page={page} />;
  else if (page.name === "provider") body = <ProviderPage tr={tr} locale={locale} go={go} page={page} />;
  else if (page.name === "forProviders") body = <ForProvidersPage tr={tr} locale={locale} go={go} />;
  else if (page.name === "articles") body = <ArticlesIndex tr={tr} locale={locale} go={go} />;
  else if (page.name === "article") body = <ArticleDetail tr={tr} locale={locale} go={go} page={page} />;
  else body = <HomePage tr={tr} locale={locale} go={go} />;

  // Full-screen surfaces (no marketing header/footer)
  const fullScreen = page.name === "signin" || page.name === "register" || page.name === "dashboard" || page.name === "claim";
  if (page.name === "signin" || page.name === "register") {
    return (
      <div className="app" dir={dir}>
        <AuthTopBar tr={tr} locale={locale} go={go} toggleLocale={toggleLocale} />
        <AuthFlow tr={tr} locale={locale} go={go} mode={page.name === "register" ? "register" : "signin"} />
      </div>
    );
  }
  if (page.name === "dashboard") {
    return (
      <div className="app" dir={dir}>
        <DashboardShell tr={tr} locale={locale} go={go} toggleLocale={toggleLocale} role={page.role} />
      </div>
    );
  }
  if (page.name === "claim") {
    return (
      <div className="app" dir={dir}>
        <AuthTopBar tr={tr} locale={locale} go={go} toggleLocale={toggleLocale} />
        <ClaimFlow tr={tr} locale={locale} go={go} />
      </div>
    );
  }

  return (
    <div className="app" dir={dir}>
      <Header tr={tr} locale={locale} page={page} go={go} toggleLocale={toggleLocale} />
      {body}
      <Footer tr={tr} go={go} locale={locale} />
      <FloatingSupport tr={tr} locale={locale} go={go} raised={page.name === "provider"} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
