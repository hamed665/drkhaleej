/* DrMuscat kit — core components (Icon, Header, Drawer, Footer, SearchPanel, primitives) */
const { useState, useEffect, useRef } = React;

/* Lucide icon as an opaque span so React never diffs the <i>→<svg> swap */
function Icon({ name, className, style }) {
  return (
    <span
      className={"ic " + (className || "")}
      style={style}
      dangerouslySetInnerHTML={{ __html: `<i data-lucide="${name}"></i>` }}
    />
  );
}
function refreshIcons() { if (window.lucide) window.lucide.createIcons(); }

/* Brand wordmark lockup — Arabic shows دكتور مسقط */
function Brand({ onClick, white, locale }) {
  return (
    <div className="brand" onClick={onClick}>
      <img src={white ? "../../assets/logo-mark-white.svg" : "../../assets/logo-mark-tile.svg"} alt="DrMuscat" />
      {locale === "ar" ? (
        <span className="wm wm-ar"><span className="dr">دكتور</span> <span className="mu">مسقط</span></span>
      ) : (
        <span className="wm"><span className="dr">Dr</span><span className="mu">Muscat</span></span>
      )}
    </div>
  );
}

function Btn({ variant = "primary", size, icon, children, onClick, block, type }) {
  const cls = ["btn", "btn-" + variant, size === "sm" ? "btn-sm" : "", block ? "btn-block" : ""].join(" ");
  return (
    <button className={cls} onClick={onClick} type={type || "button"}>
      {icon ? <Icon name={icon} /> : null}
      {children}
    </button>
  );
}

/* icon-only button (small screens / compact contact rows) */
function IconBtn({ variant = "secondary", size, icon, title, onClick }) {
  const cls = ["btn", "btn-" + variant, size === "sm" ? "btn-sm" : "", "btn-icon"].join(" ");
  return (
    <button className={cls} onClick={onClick} title={title} aria-label={title}>
      <Icon name={icon} />
    </button>
  );
}

const NAV_KEYS = ["home", "doctors", "centers", "pharmacies", "labs", "services", "articles", "search", "providers"];

function Header({ tr, locale, page, go, toggleLocale }) {
  const [drawer, setDrawer] = useState(false);
  const navTo = (k) => {
    if (k === "home") go({ name: "home" });
    else if (k === "providers") go({ name: "forProviders" });
    else if (k === "articles") go({ name: "articles" });
    else if (k === "search") go({ name: "listing", category: null });
    else go({ name: "listing", category: k });
    setDrawer(false);
  };
  const isActive = (k) => {
    if (k === "home") return page.name === "home";
    if (k === "providers") return page.name === "forProviders";
    if (k === "articles") return page.name === "articles" || page.name === "article";
    return page.name === "listing" && page.category === k;
  };
  return (
    <header className="header">
      <div className="container header-inner">
        <Brand onClick={() => go({ name: "home" })} locale={locale} />
        <nav className="nav">
          {NAV_KEYS.map((k) => (
            <a key={k} className={isActive(k) ? "active" : ""} onClick={() => navTo(k)}>{tr.nav[k]}</a>
          ))}
        </nav>
        <div className="header-right">
          <button className="lang-switch" onClick={toggleLocale}>
            <Icon name="languages" />
            <span className="lbl">{tr.langSwitchTo}</span>
          </button>
          <button className="btn btn-ghost btn-sm header-signin" onClick={() => go({ name: "signin" })}>{tr.authNav.signin}</button>
          <button className="hamburger" onClick={() => setDrawer(true)} aria-label="Menu"><Icon name="menu" /></button>
        </div>
      </div>
      <div className={"drawer" + (drawer ? " open" : "")}>
        <div className="drawer-scrim" onClick={() => setDrawer(false)}></div>
        <div className="drawer-panel">
          <div className="drawer-head">
            <Brand onClick={() => { go({ name: "home" }); setDrawer(false); }} locale={locale} />
            <button onClick={() => setDrawer(false)} aria-label="Close"><Icon name="x" /></button>
          </div>
          {NAV_KEYS.map((k) => (
            <a key={k} onClick={() => navTo(k)}>{tr.nav[k]}</a>
          ))}
          <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
            <Btn variant="primary" block onClick={() => { go({ name: "signin" }); setDrawer(false); }}>{tr.authNav.signin}</Btn>
            <Btn variant="gold" block icon="arrow-right" onClick={() => { go({ name: "forProviders" }); setDrawer(false); }}>{tr.cta.list}</Btn>
            <Btn variant="secondary" block icon="languages" onClick={() => { toggleLocale(); setDrawer(false); }}>{tr.langSwitchTo}</Btn>
          </div>
        </div>
      </div>
    </header>
  );
}

function Footer({ tr, go, locale }) {
  const L = tr.footer.links;
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div>
            <div className="brand" style={{ cursor: "default" }}>
              <img src="../../assets/logo-mark-white.svg" alt="DrMuscat" style={{ width: 34, height: 34 }} />
              {locale === "ar" ? (
                <span className="wm wm-ar" style={{ fontSize: 20, fontWeight: 600 }}>
                  <span className="dr">دكتور</span> <span className="mu">مسقط</span>
                </span>
              ) : (
                <span className="wm" style={{ fontSize: 20, fontWeight: 600 }}>
                  <span className="dr">Dr</span><span className="mu">Muscat</span>
                </span>
              )}
            </div>
            <p className="footer-tag">{tr.footer.tagline}</p>
            <div className="footer-contact"><Icon name="map-pin" />{tr.footer.contactLine}</div>
            <div className="footer-lang"><Icon name="globe" />{tr.footer.langLine}</div>
          </div>
          <div className="footer-col">
            <h4>{tr.footer.discover}</h4>
            <a onClick={() => go({ name: "listing", category: "doctors" })}>{tr.nav.doctors}</a>
            <a onClick={() => go({ name: "listing", category: "centers" })}>{tr.nav.centers}</a>
            <a onClick={() => go({ name: "listing", category: "pharmacies" })}>{tr.nav.pharmacies}</a>
            <a onClick={() => go({ name: "listing", category: "labs" })}>{tr.nav.labs}</a>
            <a onClick={() => go({ name: "listing", category: "services" })}>{tr.nav.services}</a>
            <a onClick={() => go({ name: "listing", category: null })}>{L.areas}</a>
          </div>
          <div className="footer-col">
            <h4>{tr.footer.forProviders}</h4>
            <a onClick={() => go({ name: "forProviders" })}>{L.providers}</a>
            <a onClick={() => go({ name: "forProviders" })}>{L.claim}</a>
            <a onClick={() => go({ name: "forProviders" })}>{L.howItWorks}</a>
            <a onClick={() => go({ name: "forProviders" })}>{L.trust}</a>
          </div>
          <div className="footer-col">
            <h4>{tr.footer.support}</h4>
            <a>{L.help}</a>
            <a>{L.contact}</a>
            <a>{L.accessibility}</a>
          </div>
          <div className="footer-col">
            <h4>{tr.footer.company}</h4>
            <a>{L.about}</a>
            <a>{L.privacy}</a>
            <a>{L.terms}</a>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="copy">{tr.footer.rights}</div>
          <div className="legal">
            <a>{L.privacy}</a><a>{L.terms}</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* Dependent Country → City → Area selector (Oman active; area depends on city) */
function LocationSelect({ tr, locale, span }) {
  const D = window.DM_DATA, F = tr.auth.f, soon = tr.locp.soon;
  const [city, setCity] = useState("Muscat");
  const areas = D.cityAreas[city] || [];
  const notSure = locale === "ar" ? "غير متأكد / أضيفها لاحقًا" : "Not sure / add later";
  return (
    <div className={"loc-select" + (span ? " field-span2" : "")}>
      <div className="field"><label>{F.country}</label>
        <select defaultValue="Oman">
          {D.countries.map((c) => <option key={c.code} value={c.en} disabled={!c.active}>{c[locale]}{!c.active ? " — " + soon : ""}</option>)}
        </select>
      </div>
      <div className="field"><label>{F.city}</label>
        <select value={city} onChange={(e) => setCity(e.target.value)}>
          {D.omanCities.map((c, i) => <option key={i} value={c.en}>{c[locale]}</option>)}
        </select>
      </div>
      <div className="field"><label>{F.area}</label>
        <select>
          {areas.length ? areas.map((a, i) => <option key={i}>{a[locale]}</option>) : <option>{notSure}</option>}
        </select>
      </div>
    </div>
  );
}

/* Slim top bar for full-screen auth / claim flows */
function AuthTopBar({ tr, locale, go, toggleLocale }) {
  return (
    <header className="auth-top">
      <div className="brand" onClick={() => go({ name: "home" })}>
        <img src="../../assets/logo-mark-tile.svg" alt="DrMuscat" />
        {locale === "ar"
          ? <span className="wm wm-ar"><span className="dr">دكتور</span> <span className="mu">مسقط</span></span>
          : <span className="wm"><span className="dr">Dr</span><span className="mu">Muscat</span></span>}
      </div>
      <div className="auth-top-r">
        <button className="lang-switch" onClick={toggleLocale}><Icon name="languages" /><span className="lbl">{tr.langSwitchTo}</span></button>
        <button className="btn btn-ghost btn-sm" onClick={() => go({ name: "home" })}><Icon name="x" />{locale === "ar" ? "إغلاق" : "Close"}</button>
      </div>
    </header>
  );
}

Object.assign(window, { Icon, refreshIcons, Brand, Btn, IconBtn, Header, Footer, AuthTopBar, LocationSelect, NAV_KEYS });
