/* DrMuscat kit — role-aware dashboard shell (DESIGN PREVIEW: sample data only) */

const MENU_ICON = {
  overview: "layout-dashboard", profile: "user", listings: "list", doctors: "users", affiliations: "building-2",
  services: "heart-pulse", tests: "flask-conical", schedule: "clock", gallery: "image", offers: "tag",
  leads: "inbox", verification: "badge-check", billing: "credit-card", settings: "settings", help: "life-buoy",
  saved: "bookmark", searches: "history", providers: "building-2", followups: "phone-call",
  territory: "map", commission: "percent", payouts: "wallet",
};

function StatCard({ icon, label, value, sample, tr }) {
  return (
    <div className="stat-card">
      <span className="stat-ic"><Icon name={icon} /></span>
      <div className="stat-body">
        <div className="stat-value">{value}{sample ? <span className="sample-pill">{tr.dash.sampleData}</span> : null}</div>
        <div className="stat-label">{label}</div>
      </div>
    </div>
  );
}

function StatusPill({ status, tr }) {
  return <span className={"status-pill " + status}><span className="dot"></span>{tr.dash.status[status]}</span>;
}

function OverviewPanel({ role, kind, tr, locale, go }) {
  const D = window.DM_DATA, C = tr.dash.cards;
  if (kind === "user") {
    return (
      <div className="panel">
        <div className="stat-row">
          <StatCard icon="bookmark" label={C.saved} value="0" tr={tr} />
          <StatCard icon="history" label={tr.dash.menu.searches} value="0" tr={tr} />
          <StatCard icon="map-pin" label={tr.dash.settingsArea} value="—" tr={tr} />
        </div>
        <div className="pd-block">
          <h2>{tr.dash.menu.saved}</h2>
          <div className="empty sm"><div className="ic"><Icon name="bookmark" /></div><p>{tr.dash.savedEmpty}</p>
            <Btn variant="primary" size="sm" icon="search" onClick={() => go({ name: "home" })}>{tr.search.cta}</Btn></div>
        </div>
        <div className="pd-block">
          <h2>{tr.dash.menu.searches}</h2>
          <div className="empty sm"><div className="ic"><Icon name="history" /></div><p>{tr.dash.searchEmpty}</p></div>
        </div>
      </div>
    );
  }
  if (kind === "marketer") {
    return (
      <div className="panel">
        <div className="stat-row">
          <StatCard icon="building-2" label={C.assigned} value="12" sample tr={tr} />
          <StatCard icon="loader" label={C.onboarding} value="5" sample tr={tr} />
          <StatCard icon="phone-call" label={C.followups} value="3" sample tr={tr} />
          <StatCard icon="percent" label={C.commission} value="—" tr={tr} />
        </div>
        <div className="pd-block">
          <div className="panel-head"><h2>{tr.dash.menu.leads}</h2><span className="status-pill pending"><span className="dot"></span>{tr.claim.pending}</span></div>
          <div className="lead-list">
            {D.providers.slice(0, 3).map((p) => (
              <div key={p.id} className="lead-row">
                <span className="lead-ic"><Icon name="building-2" /></span>
                <div className="lead-text"><div className="lead-name">{locale === "ar" ? p.ar : p.en}</div><div className="lead-meta">{provCat(p, locale)} · {locale === "ar" ? p.area.ar : p.area.en}</div></div>
                <span className="sample-pill">{tr.dash.sampleData}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="notice"><Icon name="info" /><p>{tr.dash.previewNote}</p></div>
      </div>
    );
  }
  if (kind === "admin" || kind === "superadmin") {
    const isSuper = kind === "superadmin";
    return (
      <div className="panel">
        <div className="stat-row">
          {isSuper ? (
            <React.Fragment>
              <StatCard icon="trending-up" label={locale === "ar" ? "نمو المنصة" : "Platform growth"} value="—" tr={tr} />
              <StatCard icon="credit-card" label={locale === "ar" ? "الإيرادات" : "Revenue"} value="—" tr={tr} />
              <StatCard icon="layers" label={tr.dash.menu.plans} value="5" sample tr={tr} />
              <StatCard icon="shield" label={tr.dash.menu.admins} value="3" sample tr={tr} />
            </React.Fragment>
          ) : (
            <React.Fragment>
              <StatCard icon="inbox" label={tr.dash.menu.listingRequests} value="6" sample tr={tr} />
              <StatCard icon="shield-check" label={tr.dash.menu.verificationQueue} value="4" sample tr={tr} />
              <StatCard icon="file-text" label={tr.dash.menu.contentReview} value="3" sample tr={tr} />
              <StatCard icon="image" label={tr.dash.menu.mediaReview} value="7" sample tr={tr} />
            </React.Fragment>
          )}
        </div>
        <div className="pd-block">
          <div className="panel-head"><h2>{isSuper ? tr.dash.menu.auditLog : tr.dash.menu.listingRequests}</h2><span className="status-pill pending"><span className="dot"></span>{tr.claim.pending}</span></div>
          <div className="lead-list">
            {D.providers.slice(0, 4).map((p) => (
              <div key={p.id} className="lead-row">
                <span className="lead-ic"><Icon name="building-2" /></span>
                <div className="lead-text"><div className="lead-name">{locale === "ar" ? p.ar : p.en}</div><div className="lead-meta">{provCat(p, locale)} · {locale === "ar" ? p.area.ar : p.area.en}</div></div>
                <span className="status-pill draft"><span className="dot"></span>{tr.dash.status.pending}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="notice warn"><Icon name="info" /><p>{tr.dash.previewNote}{isSuper ? "" : ""}</p></div>
      </div>
    );
  }
  // provider kind
  const p = D.providers[0];
  return (
    <div className="panel">
      <div className="pd-block completion-block">
        <div className="completion-head">
          <div><div className="k">{tr.dash.completion}</div><StatusPill status="pending" tr={tr} /></div>
          <div className="completion-pct">60%</div>
        </div>
        <div className="progress"><span style={{ width: "60%" }}></span></div>
        <div className="completion-actions">
          <Btn variant="primary" size="sm" icon="arrow-right" onClick={() => {}}>{tr.dash.continue}</Btn>
          <Btn variant="secondary" size="sm" icon="external-link" onClick={() => go({ name: "provider", id: p.id })}>{tr.dash.viewPublic}</Btn>
        </div>
      </div>
      <div className="stat-row">
        <StatCard icon="inbox" label={C.leads} value="0" tr={tr} />
        <StatCard icon="eye" label={C.views} value="—" tr={tr} />
        <StatCard icon="bookmark" label={C.saved} value="—" tr={tr} />
        <StatCard icon="circle-check" label={C.completion} value="60%" tr={tr} />
      </div>
      <div className="dash-2col">
        <div className="pd-block">
          <h2>{tr.newly.eyebrow === "Design preview" ? "Profile preview" : "معاينة الملف"}</h2>
          <div className="fp-preview"><ProviderCard p={p} tr={tr} locale={locale} go={go} /></div>
        </div>
        <div>
          <div className="pd-block">
            <h2 style={{ fontSize: 17 }}>{tr.dash.menu.verification}</h2>
            <p className="muted-p">{tr.dash.verifyBody}</p>
            <Btn variant="secondary" size="sm" icon="badge-check">{tr.dash.verifyCta}</Btn>
          </div>
          <div className="pd-block" style={{ marginTop: 14 }}>
            <h2 style={{ fontSize: 17 }}>{tr.billing.current}</h2>
            <div className="plan-current"><span className="plan-name">{tr.billing.currentVal}</span><span className="sample-pill">{tr.billing.soon}</span></div>
            <Btn variant="secondary" size="sm" icon="arrow-up-right">{tr.billing.upgrade}</Btn>
          </div>
        </div>
      </div>
      <div className="dash-quick">
        <button className="quick-link" onClick={() => go({ name: "claim" })}><Icon name="shield-check" />{tr.dash.claimCta}</button>
        <button className="quick-link" onClick={() => go({ name: "forProviders" })}><Icon name="plus" />{tr.dash.requestCta}</button>
      </div>
    </div>
  );
}

function BillingPanel({ tr, locale }) {
  const D = window.DM_DATA, B = tr.billing;
  return (
    <div className="panel">
      <div className="notice warn"><Icon name="info" /><p>{B.disclaimer}</p></div>
      <div className="plans-grid">
        {D.plans.map((pl) => (
          <div key={pl.id} className={"plan-card" + (pl.id === "free" ? " current" : "") + (pl.future ? " future" : "")}>
            <div className="plan-top">
              <h3>{pl[locale]}</h3>
              {pl.id === "free" ? <span className="tag-cur">{B.currentTag}</span> : pl.future ? <span className="soon-pill">{B.soon}</span> : null}
            </div>
            <div className="plan-price">—</div>
            <ul className="plan-feats">{(locale === "ar" ? pl.featsAr : pl.featsEn).map((f, i) => <li key={i}><Icon name="check" />{f}</li>)}</ul>
            <button className="btn btn-secondary btn-sm btn-block" disabled={pl.id === "free"}>{pl.id === "free" ? B.currentTag : B.choose}</button>
          </div>
        ))}
      </div>
      <div className="pd-block">
        <h2 style={{ fontSize: 17 }}>{tr.dash.planMatrix}</h2>
        <div className="matrix-scroll">
          <table className="plan-matrix">
            <thead><tr><th>{tr.dash.feature}</th>{D.planCols.map((c) => <th key={c}>{D.plans.find((p) => p.id === c)[locale]}</th>)}</tr></thead>
            <tbody>
              {D.planMatrix.map((row, i) => (
                <tr key={i}><td>{locale === "ar" ? row.ar : row.en}</td>
                  {row.v.map((on, j) => <td key={j} className="cell-c">{on ? <Icon name="check" className="mx-yes" /> : <span className="mx-no">—</span>}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="dash-2col">
        <div className="pd-block">
          <h2 style={{ fontSize: 17 }}>{B.history}</h2>
          <div className="empty sm"><div className="ic"><Icon name="receipt" /></div><p>{B.historyEmpty}</p></div>
        </div>
        <div className="pd-block">
          <h2 style={{ fontSize: 17 }}>{B.method}</h2>
          <p className="muted-p">{B.methodNote}</p>
          <div className="pay-states">
            <span className="status-pill pending"><span className="dot"></span>{B.pending}</span>
            <span className="status-pill live"><span className="dot"></span>{B.paid}</span>
            <span className="status-pill rejected"><span className="dot"></span>{B.failed}</span>
            <span className="status-pill draft"><span className="dot"></span>{B.wallet} · {B.soon}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function GenericPanel({ panelKey, role, tr, locale, go }) {
  const D = window.DM_DATA, M = tr.dash.menu;
  if (panelKey === "leads") {
    return (
      <div className="panel"><div className="pd-block">
        <h2>{M.leads}</h2>
        <div className="empty sm"><div className="ic"><Icon name="inbox" /></div><p>{tr.dash.emptyLeads}</p></div>
      </div></div>
    );
  }
  if (panelKey === "settings") {
    return (
      <div className="panel"><div className="pd-block">
        <h2>{M.settings}</h2>
        <div className="field"><label>{tr.dash.settingsLang}</label><select><option>English</option><option>العربية</option></select></div>
        <div className="field"><label>{tr.dash.settingsArea}</label><select>{D.areas.map((a,i)=><option key={i}>{a[locale]}</option>)}</select></div>
        <label className="field field-check"><input type="checkbox" defaultChecked /> <span>{tr.dash.settingsNotif}</span></label>
      </div></div>
    );
  }
  if (panelKey === "gallery") {
    return (<div className="panel"><div className="pd-block"><h2>{M.gallery}</h2>
      <div className="gallery">{[0,1,2,3,4,5].map(i=><div key={i} className="g"><Icon name="image" /></div>)}</div></div></div>);
  }
  if (panelKey === "schedule") {
    const days = locale === "ar" ? ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"] : ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    return (<div className="panel"><div className="pd-block"><h2>{M.schedule}</h2>
      <div className="sched">{days.map((d,i)=>(<div key={i} className="sched-row"><span className="sched-day">{d}</span><span className="sched-h">{i===5?"—":"8:00 – 20:00"}</span></div>))}</div></div></div>);
  }
  // services / doctors / tests / offers / affiliations / providers / followups / territory / commission / payouts / listings
  const listLike = { services: "heart-pulse", tests: "flask-conical", doctors: "users", offers: "tag",
    affiliations: "building-2", providers: "building-2", followups: "phone-call", listings: "list" };
  const icon = listLike[panelKey] || "circle";
  const items = (window.DM_DATA.providers).slice(0, 3);
  return (
    <div className="panel"><div className="pd-block">
      <div className="panel-head"><h2>{M[panelKey]}</h2><span className="sample-pill">{tr.dash.sampleData}</span></div>
      {(panelKey === "commission" || panelKey === "payouts" || panelKey === "territory") ? (
        <div className="empty sm"><div className="ic"><Icon name={icon === "circle" ? "wallet" : icon} /></div><p>{tr.dash.previewNote}</p></div>
      ) : (
        <div className="lead-list">
          {items.map((p) => (
            <div key={p.id} className="lead-row">
              <span className="lead-ic"><Icon name={icon} /></span>
              <div className="lead-text"><div className="lead-name">{locale === "ar" ? p.ar : p.en}</div><div className="lead-meta">{provCat(p, locale)}</div></div>
              <Btn variant="ghost" size="sm" icon="arrow-up-right" onClick={() => go({ name: "provider", id: p.id })}>{tr.cta.viewProfile}</Btn>
            </div>
          ))}
        </div>
      )}
    </div></div>
  );
}

function DashboardShell({ tr, locale, go, toggleLocale, role }) {
  const D = window.DM_DATA;
  const [activeRole, setActiveRole] = useState(role || "user");
  const [panel, setPanel] = useState("overview");
  const cfg = D.roleConfig[activeRole] || D.roleConfig.user;
  const roleType = D.accountTypes.find((a) => a.role === activeRole);
  const roleNames = { admin: locale === "ar" ? "مسؤول" : "Admin", superAdmin: locale === "ar" ? "مسؤول عام" : "Super Admin" };
  const roleIcons = { admin: "shield", superAdmin: "shield-alert" };
  const roleLabel = roleType ? roleType[locale] : (roleNames[activeRole] || activeRole);
  const roleIcon = roleType ? roleType.icon : (roleIcons[activeRole] || "user");

  const setRole = (r) => { setActiveRole(r); setPanel("overview"); };

  let content;
  if (panel === "overview") content = <OverviewPanel role={activeRole} kind={cfg.kind} tr={tr} locale={locale} go={go} />;
  else if (panel === "billing") content = <BillingPanel tr={tr} locale={locale} />;
  else content = <GenericPanel panelKey={panel} role={activeRole} tr={tr} locale={locale} go={go} />;

  return (
    <div className="dash">
      <aside className="dash-side">
        <div className="dash-brand" onClick={() => go({ name: "home" })}>
          <img src="../../assets/logo-mark-tile.svg" alt="DrMuscat" />
          <span className="wm" style={{ fontSize: 18, fontWeight: 600 }}>{locale === "ar" ? <span className="wm-ar"><span className="dr">دكتور</span> <span className="mu">مسقط</span></span> : <span><span className="dr">Dr</span><span className="mu">Muscat</span></span>}</span>
        </div>
        <nav className="dash-menu">
          {cfg.menu.map((k) => (
            <button key={k} className={"dash-link" + (panel === k ? " on" : "")} onClick={() => setPanel(k)}>
              <Icon name={MENU_ICON[k] || "circle"} />{tr.dash.menu[k]}
            </button>
          ))}
        </nav>
        <button className="dash-link signout" onClick={() => go({ name: "home" })}><Icon name="log-out" />{tr.authNav.signout}</button>
      </aside>

      <div className="dash-main">
        <header className="dash-top">
          <div className="dash-top-l">
            <h1>{tr.dash.menu[panel] || tr.dash.title}</h1>
            <span className="role-badge"><Icon name={roleIcon} />{roleLabel}</span>
          </div>
          <div className="dash-top-r">
            <label className="role-switch">
              <span>{tr.dash.roleSwitch}</span>
              <select value={activeRole} onChange={(e) => setRole(e.target.value)}>
                {Object.keys(D.roleConfig).map((r) => {
                  const at = D.accountTypes.find((a) => a.role === r);
                  const lbl = at ? at[locale] : (r === "admin" ? (locale === "ar" ? "مسؤول" : "Admin") : r === "superAdmin" ? (locale === "ar" ? "مسؤول عام" : "Super Admin") : r);
                  return <option key={r} value={r}>{lbl}</option>;
                })}
              </select>
            </label>
            <button className="lang-switch" onClick={toggleLocale}><Icon name="languages" /><span className="lbl">{tr.langSwitchTo}</span></button>
            <button className="btn btn-ghost btn-sm" onClick={() => go({ name: "home" })}><Icon name="external-link" />{locale === "ar" ? "الموقع" : "View site"}</button>
          </div>
        </header>
        <div className="dash-content">
          <div className="dash-preview-note"><Icon name="info" />{tr.dash.previewNote}</div>
          {content}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DashboardShell });
