/* DrMuscat kit — auth & onboarding (DESIGN ONLY: no real auth/OTP/OAuth) */

function GoogleGlyph() {
  return (
    <svg viewBox="0 0 18 18" width="18" height="18" aria-hidden="true">
      <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.71-1.57 2.68-3.89 2.68-6.62z"/>
      <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.81.54-1.84.86-3.04.86-2.34 0-4.32-1.58-5.03-3.7H.96v2.33A9 9 0 0 0 9 18z"/>
      <path fill="#FBBC05" d="M3.97 10.72A5.4 5.4 0 0 1 3.68 9c0-.6.1-1.18.29-1.72V4.95H.96A9 9 0 0 0 0 9c0 1.45.35 2.82.96 4.05l3.01-2.33z"/>
      <path fill="#EA4335" d="M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58A8.99 8.99 0 0 0 .96 4.95l3.01 2.33C4.68 5.16 6.66 3.58 9 3.58z"/>
    </svg>
  );
}

/* Field renderer used by profile setup + request form */
function SetupField({ k, tr, locale }) {
  const D = window.DM_DATA, F = tr.auth.f;
  const selects = {
    country: D.countries, city: D.omanCities, area: D.areas, category: D.categories,
  };
  if (k === "own") {
    return (
      <label className="field field-check">
        <input type="checkbox" /> <span>{F.own}</span>
      </label>
    );
  }
  if (k === "note") {
    return (<div className="field"><label>{F.note}</label><textarea placeholder={F.note}></textarea></div>);
  }
  if (k === "lang") {
    return (<div className="field"><label>{F.lang}</label><select><option>{F.langEn}</option><option>{F.langAr}</option></select></div>);
  }
  if (k === "providerType") {
    return (<div className="field"><label>{F.providerType}</label><select>{D.accountTypes.slice(1).map((a) => <option key={a.id}>{a[locale]}</option>)}</select></div>);
  }
  if (k === "location") {
    return <LocationSelect tr={tr} locale={locale} span />;
  }
  if (selects[k]) {
    return (
      <div className="field"><label>{F[k]}</label>
        <select>{selects[k].map((o, i) => <option key={i}>{o[locale]}{o.active === false ? " — " + tr.locp.soon : ""}</option>)}</select>
      </div>
    );
  }
  const labelMap = { name: F.name, nameOpt: F.nameOpt, specialty: F.specialty, clinic: F.clinic, center: F.center,
    business: F.business, contact: F.contact, phone: F.phone, whatsapp: F.whatsapp, email: F.email, territory: F.territory };
  return (<div className="field"><label>{labelMap[k]}</label><input placeholder={labelMap[k]} /></div>);
}

const SETUP_FIELDS = {
  user: ["nameOpt", "lang", "location"],
  doctor: ["name", "specialty", "clinic", "location", "phone", "whatsapp", "lang"],
  center: ["center", "category", "location", "contact", "phone", "whatsapp", "email", "own"],
  pharmacy: ["business", "providerType", "location", "contact", "phone", "whatsapp", "email"],
  lab: ["business", "providerType", "location", "contact", "phone", "whatsapp", "email"],
  beauty: ["business", "providerType", "location", "contact", "phone", "whatsapp", "email"],
  pet: ["business", "providerType", "location", "contact", "phone", "whatsapp", "email"],
  provider: ["business", "providerType", "location", "contact", "phone", "whatsapp", "email"],
  marketer: ["name", "phone", "whatsapp", "location", "lang", "territory", "note"],
};

function AuthFlow({ tr, locale, go, mode }) {
  const D = window.DM_DATA, A = tr.auth;
  const [step, setStep] = useState("start");      // start | password | forgot | otp | google | type | ptype | setup
  const [otpSent, setOtpSent] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [acct, setAcct] = useState(null);

  const isReg = mode === "register";
  const backIcon = locale === "ar" ? "arrow-right" : "arrow-left";
  const headTitle = step === "start" ? (isReg ? A.registerTitle : A.signinTitle) :
    step === "password" ? (isReg ? A.registerTitle : A.signinTitle) :
    step === "forgot" ? A.reset :
    step === "otp" ? A.otpTitle : step === "google" ? A.googleDoneTitle :
    step === "type" ? A.typeTitle : step === "ptype" ? A.typeTitle : A.setupTitle;
  const headSub = step === "start" ? (isReg ? A.registerSub : A.signinSub) :
    step === "password" ? (isReg ? A.registerSub : A.signinSub) :
    step === "forgot" ? A.resetSub :
    step === "otp" ? (A.otpSub + " +968 9XX XXX") : step === "google" ? A.googleDoneSub :
    step === "type" ? A.typeSub : step === "ptype" ? A.typeSub : A.setupSub;

  const finish = () => { const role = (acct && acct.role) || "user"; go({ name: "dashboard", role }); };
  const pickMain = (m) => {
    if (m.id === "provider") { setStep("ptype"); return; }
    setAcct(m); setStep("setup");
  };

  return (
    <main className="auth-wrap">
      <div className="auth-card">
        <div className="auth-mark"><img src="../../assets/logo-mark-tile.svg" alt="DrMuscat" /></div>
        <h1 className="auth-title">{headTitle}</h1>
        <p className="auth-sub">{headSub}</p>

        {step === "start" ? (
          <div className="auth-methods">
            <button className="btn auth-google" onClick={() => setStep("google")}><GoogleGlyph />{A.google}</button>
            <button className="btn btn-primary btn-block" onClick={() => { setStep("otp"); setOtpSent(false); }}>
              <Icon name="phone" />{A.phone}
            </button>
            <button className="btn btn-secondary btn-block" onClick={() => setStep("password")}>
              <Icon name="lock" />{A.password}
            </button>
            {!isReg ? <button className="btn btn-ghost btn-block" onClick={() => go({ name: "home" })}>{A.guest}</button> : null}
            <p className="auth-terms">{A.terms}</p>
            <div className="auth-switch">
              {isReg
                ? <span>{tr.authNav.signin}? <a onClick={() => go({ name: "signin" })}>{tr.authNav.signin}</a></span>
                : <span><a onClick={() => go({ name: "register" })}>{tr.authNav.register}</a></span>}
            </div>
          </div>
        ) : null}

        {step === "password" ? (
          <div className="auth-body">
            <div className="field"><label>{A.emailPhone}</label><input placeholder={A.emailPhone} /></div>
            <div className="field"><label>{isReg ? A.createPwd : A.pwd}</label><input type="password" placeholder="••••••••" /></div>
            {isReg ? <div className="field"><label>{A.confirmPwd}</label><input type="password" placeholder="••••••••" /></div> : null}
            <button className="btn btn-primary btn-block" onClick={() => setStep(isReg ? "type" : "type")}>{isReg ? A.next : A.signinPwd}</button>
            {!isReg ? <div className="auth-otp-links"><a onClick={() => { setStep("forgot"); setResetSent(false); }}>{A.forgot}</a></div> : null}
            <button className="btn btn-ghost btn-sm auth-back" onClick={() => setStep("start")}><Icon name={backIcon} />{A.back}</button>
          </div>
        ) : null}

        {step === "forgot" ? (
          <div className="auth-body">
            {!resetSent ? (
              <React.Fragment>
                <div className="field"><label>{A.emailPhone}</label><input placeholder={A.emailPhone} /></div>
                <button className="btn btn-primary btn-block" onClick={() => setResetSent(true)}>{A.sendReset}</button>
              </React.Fragment>
            ) : (
              <div className="auth-connected"><Icon name="mail-check" /><span>{A.sendReset} ✓</span></div>
            )}
            <button className="btn btn-ghost btn-sm auth-back" onClick={() => setStep("password")}><Icon name={backIcon} />{A.back}</button>
          </div>
        ) : null}

        {step === "otp" ? (
          <div className="auth-body">
            {!otpSent ? (
              <React.Fragment>
                <div className="field"><label>{A.phoneLabel}</label><input placeholder={A.phonePlaceholder} defaultValue="+968 " /></div>
                <button className="btn btn-primary btn-block" onClick={() => setOtpSent(true)}>{A.sendOtp}</button>
              </React.Fragment>
            ) : (
              <React.Fragment>
                <div className="otp-row">
                  {[0,1,2,3,4,5].map((i) => <input key={i} className="otp-box" maxLength="1" defaultValue={i < 2 ? String(i+3) : ""} />)}
                </div>
                <button className="btn btn-primary btn-block" onClick={() => setStep("type")}>{A.verify}</button>
                <div className="auth-otp-links">
                  <a onClick={() => {}}>{A.resend}</a>
                  <a onClick={() => setOtpSent(false)}>{A.changeNumber}</a>
                </div>
              </React.Fragment>
            )}
            <button className="btn btn-ghost btn-sm auth-back" onClick={() => setStep("start")}><Icon name={locale === "ar" ? "arrow-right" : "arrow-left"} />{A.back}</button>
          </div>
        ) : null}

        {step === "google" ? (
          <div className="auth-body">
            <div className="auth-connected"><GoogleGlyph /><span>name@gmail.com</span><Icon name="check" /></div>
            <button className="btn btn-primary btn-block" onClick={() => setStep("type")}>{A.next}</button>
            <button className="btn btn-ghost btn-sm auth-back" onClick={() => setStep("start")}><Icon name={locale === "ar" ? "arrow-right" : "arrow-left"} />{A.back}</button>
          </div>
        ) : null}

        {step === "type" ? (
          <div className="auth-body">
            <div className="acct-grid">
              {D.accountTypes.filter((a) => a.id !== "other").map((a) => (
                <button key={a.id} className="acct-card" onClick={() => { setAcct(a); setStep("setup"); }}>
                  <span className="acct-ic"><Icon name={a.icon} /></span>
                  <span className="acct-label">{a[locale]}</span>
                  <Icon name={locale === "ar" ? "chevron-left" : "chevron-right"} className="acct-check" />
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {step === "ptype" ? (
          <div className="auth-body">
            <div className="acct-grid">
              {D.providerTypes.map((p) => (
                <button key={p.id} className={"acct-card" + (acct && acct.id === p.id ? " on" : "")} onClick={() => setAcct(p)}>
                  <span className="acct-ic"><Icon name={p.icon} /></span>
                  <span className="acct-label">{p[locale]}</span>
                  {acct && acct.id === p.id ? <Icon name="check" className="acct-check" /> : null}
                </button>
              ))}
            </div>
            <div className="auth-actions">
              <button className="btn btn-ghost" onClick={() => { setAcct(null); setStep("type"); }}>{A.back}</button>
              <button className="btn btn-primary" disabled={!acct} onClick={() => setStep("setup")}>{A.next}</button>
            </div>
          </div>
        ) : null}

        {step === "setup" ? (
          <div className="auth-body auth-setup">
            <div className="setup-role"><Icon name={acct.icon} />{acct[locale]}</div>
            <div className="setup-grid">
              {(SETUP_FIELDS[acct.role] || SETUP_FIELDS.provider).map((k) => <SetupField key={k} k={k} tr={tr} locale={locale} />)}
            </div>
            <div className="auth-actions">
              <button className="btn btn-ghost" onClick={() => setStep("type")}>{A.back}</button>
              <button className="btn btn-primary" onClick={finish}><Icon name="check" />{A.finish}</button>
            </div>
          </div>
        ) : null}
      </div>
    </main>
  );
}

/* ---------------- Claim profile flow ---------------- */
function ClaimFlow({ tr, locale, go }) {
  const D = window.DM_DATA, C = tr.claim;
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState(null);
  const total = C.steps.length;

  return (
    <main className="section">
      <div className="container claim-wrap">
        <div className="breadcrumb">
          <a onClick={() => go({ name: "forProviders" })}>{tr.nav.providers}</a>
          <Icon name="chevron-right" /><span>{C.title}</span>
        </div>
        <h1 className="claim-title">{C.title}</h1>

        <div className="stepper">
          {C.steps.map((s, i) => (
            <div key={i} className={"step" + (i === step ? " on" : "") + (i < step ? " done" : "")}>
              <span className="step-n">{i < step ? "✓" : (locale === "ar" ? toAr(i + 1) : i + 1)}</span>
              <span className="step-lbl">{s}</span>
            </div>
          ))}
        </div>

        <div className="claim-card">
          {step === 0 ? (
            <div>
              <div className="sb-input claim-search"><Icon name="search" /><input placeholder={C.searchPlaceholder} /></div>
              <div className="claim-results">
                {D.providers.slice(0, 4).map((p) => (
                  <button key={p.id} className={"claim-row" + (picked === p.id ? " on" : "")} onClick={() => setPicked(p.id)}>
                    <span className="claim-row-ic"><Icon name="building-2" /></span>
                    <span className="claim-row-text">
                      <span className="claim-row-name">{locale === "ar" ? p.ar : p.en}</span>
                      <span className="claim-row-meta">{provCat(p, locale)} · {locale === "ar" ? p.area.ar : p.area.en}</span>
                    </span>
                    <span className="claim-pick">{picked === p.id ? C.selected : C.select}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {step === 1 ? (
            <div className="claim-confirm">
              <div className="notice"><Icon name="shield-check" /><p>{C.title} — {tr.provider.notice}</p></div>
              <label className="field field-check"><input type="checkbox" defaultChecked /> <span>{C.own}</span></label>
            </div>
          ) : null}

          {step === 2 ? (
            <div>
              <div className="field"><label>{C.phone}</label><input defaultValue="+968 " /></div>
              <button className="btn btn-secondary btn-sm" style={{ marginBottom: 14 }}>{C.sendOtp}</button>
              <div className="otp-row">{[0,1,2,3,4,5].map((i) => <input key={i} className="otp-box" maxLength="1" defaultValue={i<2?String(i+1):""} />)}</div>
            </div>
          ) : null}

          {step === 3 ? (
            <div>
              <div className="upload-box"><Icon name="upload" /><div><div className="upload-t">{C.docTitle}</div><div className="upload-n">{C.docNote}</div></div><button className="btn btn-secondary btn-sm">{C.docCta}</button></div>
            </div>
          ) : null}

          {step === 4 ? (
            <div className="claim-done">
              <div className="done-ic"><Icon name="check" /></div>
              <h2>{C.doneTitle}</h2>
              <p>{C.doneBody}</p>
              <span className="status-pill pending"><Icon name="clock" />{C.pending}</span>
            </div>
          ) : null}

          {step < total - 1 ? (
            <div className="auth-actions" style={{ marginTop: 18 }}>
              {step > 0 ? <button className="btn btn-ghost" onClick={() => setStep(step - 1)}>{C.back}</button> : <span></span>}
              <button className="btn btn-primary" disabled={step === 0 && !picked} onClick={() => setStep(step + 1)}>{step === 3 ? C.submit : C.next}</button>
            </div>
          ) : (
            <div className="auth-actions" style={{ marginTop: 18 }}>
              <button className="btn btn-secondary" onClick={() => go({ name: "dashboard", role: "center" })}>{tr.authNav.dashboard}</button>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}

function toAr(n) { return String(n).replace(/[0-9]/g, (d) => "٠١٢٣٤٥٦٧٨٩"[d]); }

Object.assign(window, { AuthFlow, ClaimFlow, GoogleGlyph, toAr });
