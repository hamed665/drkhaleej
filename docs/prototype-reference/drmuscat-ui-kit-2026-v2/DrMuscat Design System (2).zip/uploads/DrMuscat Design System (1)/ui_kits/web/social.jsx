/* DrMuscat kit — FAQ accordion, reviews/ratings, comments (design-only, honest empty states) */

function FAQ({ items, tr }) {
  const [open, setOpen] = useState(0);
  if (!items || !items.length) return null;
  return (
    <div className="faq">
      <SectionHead eyebrow={tr.faq.sub} title={tr.faq.title} />
      <div className="faq-list">
        {items.map((it, i) => (
          <div key={i} className={"faq-item" + (open === i ? " open" : "")}>
            <button className="faq-q" onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}>
              <span>{it.q}</span><Icon name={open === i ? "minus" : "plus"} />
            </button>
            {open === i ? <div className="faq-a">{it.a}</div> : null}
          </div>
        ))}
      </div>
    </div>
  );
}

/* Stars — display (read-only) or input */
function Stars({ value, onPick }) {
  return (
    <span className="stars">
      {[1, 2, 3, 4, 5].map((n) => (
        onPick
          ? <button key={n} type="button" className={"star-btn" + (n <= value ? " on" : "")} onClick={() => onPick(n)} aria-label={n + " star"}><Icon name="star" /></button>
          : <Icon key={n} name="star" className={"star" + (n <= value ? " on" : "")} />
      ))}
    </span>
  );
}

/* Reviews & ratings — honest: empty state + moderated write flow, never fabricated */
function ReviewsBlock({ tr, locale }) {
  const R = tr.reviews;
  const [writing, setWriting] = useState(false);
  const [rating, setRating] = useState(0);
  const [sent, setSent] = useState(false);
  return (
    <div className="pd-block" id="reviews">
      <div className="panel-head">
        <h2>{R.title}</h2>
        {!writing ? <Btn variant="secondary" size="sm" icon="pencil" onClick={() => { setWriting(true); setSent(false); }}>{R.write}</Btn> : null}
      </div>

      <div className="rev-summary">
        <div className="rev-score">
          <Stars value={0} />
          <span className="rev-score-lbl">{R.summaryEmpty}</span>
        </div>
        <div className="rev-controls">
          <button className="chip" disabled><Icon name="arrow-up-down" />{R.sort}</button>
          <button className="chip" disabled><Icon name="filter" />{R.filter}</button>
        </div>
      </div>

      {writing ? (
        sent ? (
          <div className="rev-sent">
            <span className="status-pill pending"><span className="dot"></span>{R.pending}</span>
            <p className="muted-p" style={{ marginTop: 10 }}>{R.note}</p>
            <Btn variant="ghost" size="sm" onClick={() => { setWriting(false); setRating(0); }}>{R.cancel}</Btn>
          </div>
        ) : (
          <div className="rev-form">
            <div className="field"><label>{R.yourRating}</label><Stars value={rating} onPick={setRating} /></div>
            <div className="field"><label>{R.yourReview}</label><textarea placeholder={R.placeholder}></textarea></div>
            <div className="auth-actions">
              <button className="btn btn-ghost" onClick={() => setWriting(false)}>{R.cancel}</button>
              <button className="btn btn-primary" onClick={() => setSent(true)}><Icon name="send" />{R.submit}</button>
            </div>
            <div className="form-note">{R.note}</div>
          </div>
        )
      ) : (
        <div className="empty sm rev-empty">
          <div className="ic"><Icon name="message-square" /></div>
          <p>{R.empty}</p>
        </div>
      )}
    </div>
  );
}

function CommentsBlock({ tr, locale }) {
  const C = tr.comments;
  const [sent, setSent] = useState(false);
  return (
    <div className="pd-block" id="comments">
      <h2>{C.title}</h2>
      <div className="empty sm" style={{ padding: "22px 16px" }}><div className="ic"><Icon name="message-circle" /></div><p>{C.empty}</p></div>
      <div className="field" style={{ marginTop: 8 }}><label>{C.add}</label><textarea placeholder={C.placeholder}></textarea></div>
      {sent ? <span className="status-pill pending" style={{ marginBottom: 10 }}><span className="dot"></span>{C.pending}</span> : null}
      <button className="btn btn-primary btn-sm" onClick={() => setSent(true)}><Icon name="send" />{C.submit}</button>
      <div className="form-note">{C.note}</div>
    </div>
  );
}

Object.assign(window, { FAQ, Stars, ReviewsBlock, CommentsBlock });
