# DrMuscat — Design System

> Oman-first, bilingual (English + Arabic) healthcare **discovery** platform for Muscat.
> Calm, premium, trustworthy, medically-safe, warm — never flashy, never a marketplace template.

DrMuscat helps people in Muscat **find** trusted clinics, dentists, pharmacies, laboratories, and beauty &
wellness providers. It is a *discovery* product — search-first, content-led — not a booking marketplace, not a
coupon site, not a hospital management system. Arabic is a first-class language, designed natively for RTL, not
mirrored from the English layout.

This folder is a complete, self-contained design system: brand foundations (color, type, spacing, elevation),
real visual assets (logo marks), an iconography approach, and a high-fidelity, interactive **UI kit** that
recreates the core web surfaces. Everything is built so it can later be lifted into a clean, scoped Next.js
frontend without touching data, Supabase, SEO, sitemap, robots, or backend logic.

---

## ⚠️ Provenance & important note

There was **no existing codebase, Figma, or brand kit** provided for DrMuscat. This system was therefore
**designed from the brief** rather than reverse-engineered from a source of truth. All visual decisions (palette,
type pairing, logo, motifs) are original proposals intended as a starting point to iterate on.

**Substitutions / things to confirm with the stakeholder:**
- **Typeface — `Readex Pro`** (Google Fonts). Chosen because it is a single family that covers **Latin and
  Arabic** with harmonized proportions, so bilingual layouts share one type voice. Loaded via Google Fonts CDN
  (no local `.ttf` shipped). *If you have a licensed brand font, send it and I'll swap it in.*
- **Iconography — `Lucide`** (CDN). Clean, even-stroke line icons that read as calm and medical-safe. Swap for a
  licensed set if one exists.
- **Logo** — designed here as a simple location-pin + medical-plus mark with a `DrMuscat` wordmark. Treat as a
  proposal, not a final identity.
- **No real provider data** is used anywhere — by requirement. No ratings, reviews, counts, "top doctor" labels,
  live availability, or sponsored blocks. Sample cards use only *structural, factual* fields.

---

## Products / surfaces

| Surface | What it is | Where |
|---|---|---|
| **Web — Discovery** | Search-first homepage, results/listing, provider detail | `ui_kits/web/` |

The web kit ships an interactive click-through prototype with a real **EN ⇄ AR (LTR ⇄ RTL)** toggle so the
Arabic experience can be judged on its own terms.

---

## CONTENT FUNDAMENTALS — how DrMuscat writes

The voice is **calm, plain, and reassuring** — a knowledgeable local guide, not a salesperson and not a
hospital form. Copy earns trust by being clear and specific, never hypey.

- **Person:** Speak to the user as **"you"**; the product refers to itself rarely and never as "we the best".
  Prefer the imperative for actions ("Find a clinic near you", "Search pharmacies").
- **Tone:** Warm, competent, unhurried. Healthcare-safe — no urgency tricks, no "Only 2 slots left!", no
  discounts, no superlatives ("#1", "best", "top-rated").
- **Casing:** Sentence case everywhere — headings, buttons, nav. **No ALL-CAPS** except the small Latin eyebrow
  label (and even that is dropped in Arabic).
- **Length:** Short. Headlines are a phrase, not a sentence. Supporting copy is one or two calm lines.
- **Numbers & claims:** Only state what is factual and verifiable (listed hours, area, services, languages
  spoken, insurance accepted). **Never** invent ratings, review counts, popularity, or availability.
- **Emoji:** **None.** Iconography carries meaning instead.
- **Bilingual copywriting:** Arabic is written *as Arabic*, not translated word-for-word. Arabic screens contain
  **no English navigation or English button labels**. Keep Arabic concise — Arabic text runs visually larger, so
  copy is kept tight to avoid oversized headings.

**Examples**
- Hero (EN): *"Find trusted healthcare in Muscat."* / sub: *"Search clinics, pharmacies, labs and wellness — all in one calm place."*
- Hero (AR): *«اعثر على رعاية صحية موثوقة في مسقط.»* / sub: *«ابحث عن العيادات والصيدليات والمختبرات والعناية في مكان واحد.»*
- Buttons: *Search* · *View profile* · *Show on map* · *Get directions* — never *Book now & save!*
- Empty state: *"No results in this area yet. Try a nearby neighbourhood."* — helpful, never apologetic-spammy.

---

## VISUAL FOUNDATIONS

The system's job is to feel **calm and trustworthy**. It does this with generous white space, a restrained
palette, soft elevation, and one confident brand color. Decoration is minimal.

- **Color vibe.** A single **deep teal-green** (`#0E6E64`) is the identity — healthcare-associated but warmer
  and more premium than clinical blue. **Omani gold** (`#C9A24B`) is an *accent*, used sparingly (a CTA on dark,
  a highlight, the wordmark's "Dr"), never as a fill for large areas. Neutrals are a warm-cool slate with a faint
  green undertone so nothing feels grey-corporate. Backgrounds are near-white (`#F7FAF9`), occasionally a warm
  off-white band (`#FBFBF8`).
- **Type.** One family, **Readex Pro**, across both languages. Headlines are **semibold (600)** with tight
  tracking (`-0.02em`); body is regular at `1.6` line-height. Arabic uses the *same* family but with no negative
  tracking and a slightly larger line-height for naskh legibility — and Arabic display sizes are kept **smaller**
  than a naïve port would use, to avoid the "shouting Arabic heading" problem.
- **Spacing & layout.** A 4-based scale. Cards pad at `24px`; sections breathe at `48–80px`. Content sits on a
  max-width column; the homepage **search panel is always above the fold** — it is the first thing rendered, never
  pushed down by a tall hero. Layout is responsive and componentized for a clean Next.js port.
- **Backgrounds.** Mostly flat near-white. **No** loud full-bleed gradients. A *very* soft teal-tint wash
  (`teal-50 → teal-100`) may sit behind the hero search or image placeholders. No textures, no noise, no
  patterned wallpaper. Imagery, where present, is warm and human (see Imagery below).
- **Imagery.** Mixed approach: **warm photography** for providers/clinics (placeholders here — no stock shipped),
  and **calm category tinting** for the six categories. Image tone is warm, natural, well-lit — never cold,
  never heavy grain, never black-and-white. Image placeholders use a soft teal gradient with a line icon.
- **Corner radii.** Soft but not bubbly. Cards & inputs `12–16px`; the search bar, chips and filters are full
  **pills**; the logo tile `15px`. Avoid hard 0px corners and avoid oversized 28px+ except on large hero panels.
- **Cards.** White surface, `16px` radius, a **1px hairline** (`--line-soft`) *and* a soft shadow
  (`--shadow-sm`). On hover they lift to `--shadow-md` and the border warms slightly. No colored left-border
  accent stripes (an AI-slop trope we explicitly avoid).
- **Shadows / elevation.** Soft, low-contrast, tinted with greenish ink (`rgba(11,40,38,…)`) rather than pure
  black, so shadows feel like daylight, not drop-shadow. Four steps: `xs` hairline, `sm` resting card, `md`
  hover/menu, `lg` modal/floating search.
- **Borders.** Hairlines (`1px`, `#E2E9E7`). Used for dividers, input outlines, and card edges. Focus uses a
  3px teal ring (`--focus`) plus a slightly stronger inset border — visible but calm.
- **Transparency & blur.** Used sparingly and purposefully: the floating "Verified" tag over an image uses a
  translucent white with a small `backdrop-filter: blur`; a sticky header may gain a blurred translucent
  background on scroll. Never decorative glassmorphism everywhere.
- **Hover states.** Buttons darken one teal step (`700 → 800`); cards lift; links underline; chips fill with
  `teal-50`. No scale-up bounce on hover.
- **Press states.** Buttons darken a further step (`800 → 900`) and nudge `0.5px` down — a subtle physical
  press, no aggressive shrink.
- **Motion.** Quiet and quick. `150–220ms`, ease `cubic-bezier(0.2, 0.0, 0.0, 1)` (gentle decelerate). Fades and
  small `4–8px` rises for entrances. **No** bounces, no infinite loops, no parallax. Respect
  `prefers-reduced-motion`.
- **Protection.** Text over imagery sits on a translucent capsule or a soft bottom gradient — never raw text on
  a busy photo.

---

## ICONOGRAPHY

- **Set:** **Lucide** (open-source, MIT) loaded from CDN. Even **1.75px stroke**, rounded caps and joins, line
  (not filled) style — which reads calm and clinical-safe without being cold.
- **Usage:** Icons support labels; they rarely stand alone. Category icons: `stethoscope` (clinics), `smile`
  (dental), `pill` (pharmacy), `flask-conical` (lab), `sparkles` (beauty), `flower-2` (wellness). UI icons:
  `search`, `map-pin`, `clock`, `phone`, `badge-check`, `shield-check`, `video`, `globe`, `filter`,
  `sliders-horizontal`, `navigation`, `chevron-*`.
- **RTL:** Directional icons (chevrons, arrows, `navigation`) **flip** under RTL; symbolic icons (pin, clock,
  pill) do **not**.
- **Sizing:** `16–20px` inline, `34px` for large/empty-state. Inherit `currentColor`; default `--ink-700`,
  active `--teal-700`.
- **Emoji / unicode icons:** **Never.** No emoji anywhere in the product. Eastern-Arabic numerals are available
  for Arabic contexts but Western numerals are the default in Omani commercial UIs.
- The brand **logo mark** (`assets/logo-mark*.svg`) is a custom pin + medical-plus; it is not part of the Lucide
  set and is the only bespoke glyph.

---

## Index — what's in this folder

| Path | What |
|---|---|
| `README.md` | This file — context, content & visual rules, iconography |
| `colors_and_type.css` | All design tokens: colors, type scale, spacing, radii, shadows. **Import this everywhere.** |
| `assets/logo-mark.svg` | Brand mark (teal, transparent plus) |
| `assets/logo-mark-white.svg` | Brand mark (white, for dark backgrounds) |
| `assets/logo-mark-tile.svg` | Brand mark on a teal rounded tile (app icon / lockup) |
| `preview/*.html` | Design-system specimen cards (colors, type, spacing, components, brand) |
| `ui_kits/web/` | High-fidelity interactive web UI kit — see its own `README.md` |
| `SKILL.md` | Agent-skill manifest so this system can be used by Claude Code |

**Fonts:** `Readex Pro` via Google Fonts CDN (Latin + Arabic). No local files shipped — flag if you need them
embedded/offline.
